/**
 * FamaClub Records — Pruebas de lógica de negocio
 * Corre en Node con un shim mínimo de localStorage (nada de DOM real:
 * estos módulos están deliberadamente desacoplados de la UI).
 * Uso: node tests/run-tests.js
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

// ---------------- Shim de localStorage ----------------
class LocalStorageShim {
  constructor() { this.store = {}; }
  getItem(k) { return Object.prototype.hasOwnProperty.call(this.store, k) ? this.store[k] : null; }
  setItem(k, v) { this.store[k] = String(v); }
  removeItem(k) { delete this.store[k]; }
  clear() { this.store = {}; }
}

function loadModules(sandbox) {
  const files = ['models.js', 'storage.js', 'settings.js', 'players.js', 'state-game.js', 'state-beer.js', 'stats.js'];
  files.forEach((f) => {
    const code = fs.readFileSync(path.join(__dirname, '..', 'app', 'js', f), 'utf8');
    vm.runInContext(code, sandbox, { filename: f });
  });
  // `const` de nivel superior no queda como propiedad del objeto sandbox
  // (igual que en un navegador real con `window`), así que las exponemos
  // explícitamente para poder usarlas como ctx.Models, ctx.StateGame, etc.
  vm.runInContext(
    'this.Models=Models; this.Storage=Storage; this.AppSettings=AppSettings; ' +
    'this.Players=Players; this.StateGame=StateGame; this.StateBeer=StateBeer; this.Stats=Stats;',
    sandbox
  );
}

function freshContext() {
  const localStorage = new LocalStorageShim();
  const sandbox = { localStorage, console, window: { matchMedia: () => ({ matches: false, addEventListener() {} }) }, navigator: {} };
  vm.createContext(sandbox);
  loadModules(sandbox);
  return sandbox;
}

// ---------------- Runner mínimo ----------------
let pass = 0, fail = 0;
function assert(cond, msg) {
  if (cond) { pass++; }
  else { fail++; console.error('  ✗ FALLÓ:', msg); }
}
function test(name, fn) {
  console.log(`\n${name}`);
  try { fn(); } catch (e) { fail++; console.error('  ✗ EXCEPCIÓN:', e.message); }
}

// ================= PRUEBAS =================

test('Crear partida con 4 jugadores y 2 equipos', () => {
  const ctx = freshContext();
  const p1 = ctx.Players.getOrCreate('Juan');
  const p2 = ctx.Players.getOrCreate('José');
  const p3 = ctx.Players.getOrCreate('María');
  const p4 = ctx.Players.getOrCreate('Estefanía');
  const game = ctx.StateGame.newGame({
    team1Name: 'Los Tigres', team2Name: 'Los Leones',
    player1Id: p1.id, player2Id: p2.id, player3Id: p3.id, player4Id: p4.id,
    targetScore: 100, beerEnabled: false, beerRule: ctx.Models.defaultBeerRule(),
  });
  assert(game.team1.playerIds.length === 2, 'equipo 1 debe tener 2 jugadores');
  assert(game.team2.playerIds.length === 2, 'equipo 2 debe tener 2 jugadores');
  assert(game.status === 'active', 'la partida nueva debe estar activa');
  assert(ctx.Players.all().length === 4, 'deben existir 4 jugadores guardados');
});

test('Cambiar nombres de equipo', () => {
  const ctx = freshContext();
  setupBasicGame(ctx);
  const game = ctx.StateGame.getGame();
  const ok = ctx.StateGame.updateTeamName(game.team1.id, 'Nuevo Nombre');
  assert(ok === true, 'renombrar debe retornar true');
  assert(ctx.StateGame.getGame().team1.name === 'Nuevo Nombre', 'el nombre debe actualizarse');
  const fail1 = ctx.StateGame.updateTeamName(game.team1.id, '   ');
  assert(fail1 === false, 'no debe permitir nombre vacío');
});

test('Agregar puntos y que el marcador se derive del historial', () => {
  const ctx = freshContext();
  setupBasicGame(ctx);
  const game = ctx.StateGame.getGame();
  ctx.StateGame.addPoints(game.team1.id, 30);
  ctx.StateGame.addPoints(game.team2.id, 20);
  ctx.StateGame.addPoints(game.team1.id, 15);
  const s = ctx.StateGame.scores();
  assert(s.team1 === 45, `team1 debería tener 45, tiene ${s.team1}`);
  assert(s.team2 === 20, `team2 debería tener 20, tiene ${s.team2}`);
  assert(ctx.Models.scoreFor(ctx.StateGame.getGame(), game.team1.id) === 45, 'scoreFor debe coincidir con scores()');
});

test('Editar y eliminar anotaciones recalcula el marcador', () => {
  const ctx = freshContext();
  setupBasicGame(ctx);
  const game = ctx.StateGame.getGame();
  ctx.StateGame.addPoints(game.team1.id, 10);
  const entry = ctx.StateGame.getGame().entries[0];
  ctx.StateGame.editEntry(entry.id, 25);
  assert(ctx.StateGame.scores().team1 === 25, 'editar debe recalcular el total');
  ctx.StateGame.deleteEntry(entry.id);
  assert(ctx.StateGame.scores().team1 === 0, 'eliminar debe recalcular el total a 0');
});

test('Deshacer y rehacer', () => {
  const ctx = freshContext();
  setupBasicGame(ctx);
  const game = ctx.StateGame.getGame();
  ctx.StateGame.addPoints(game.team1.id, 10);
  ctx.StateGame.addPoints(game.team1.id, 5);
  assert(ctx.StateGame.scores().team1 === 15, 'antes de deshacer debe ser 15');
  ctx.StateGame.undo();
  assert(ctx.StateGame.scores().team1 === 10, 'después de deshacer debe ser 10');
  ctx.StateGame.redo();
  assert(ctx.StateGame.scores().team1 === 15, 'después de rehacer debe volver a 15');
  assert(ctx.StateGame.canUndo() === true, 'debe poder seguir deshaciendo');
});

test('Detección de ganador al alcanzar la meta', () => {
  const ctx = freshContext();
  setupBasicGame(ctx, 100);
  const game = ctx.StateGame.getGame();
  ctx.StateGame.addPoints(game.team1.id, 101);
  const updated = ctx.StateGame.getGame();
  assert(updated.status === 'finished', 'la partida debe marcarse finished');
  assert(updated.winnerTeamId === game.team1.id, 'team1 debe ser el ganador');
});

test('Corregir una anotación que produce un empate exacto reabre la partida', () => {
  // Caso borde real: el usuario corrige un punto DESPUÉS de que la partida
  // ya se dio por terminada, y esa corrección deja a ambos equipos exactamente
  // empatados en la meta. checkWinner() debe negarse a declarar ganador y
  // syncWinnerState() debe reabrir la partida en vez de dejar un estado inválido.
  const ctx = freshContext();
  const game = setupBasicGame(ctx, 100);
  ctx.StateGame.addPoints(game.team1.id, 40);
  ctx.StateGame.addPoints(game.team2.id, 40);
  ctx.StateGame.editEntry(ctx.StateGame.getGame().entries[0].id, 100); // team1 llega a 100 → gana, finished
  assert(ctx.StateGame.getGame().status === 'finished', 'debe finalizar cuando team1 llega a 100');

  ctx.StateGame.editEntry(ctx.StateGame.getGame().entries[1].id, 100); // team2 también llega a 100 → empate
  const afterTie = ctx.StateGame.getGame();
  assert(afterTie.status === 'active', 'un empate exacto en la meta debe reabrir la partida, no dejar un ganador inválido');
  assert(afterTie.winnerTeamId === null, 'no debe quedar ningún ganador registrado en el empate');
});

test('Guardar partida activa y recuperarla (continuar partida)', () => {
  const ctx = freshContext();
  setupBasicGame(ctx);
  const game = ctx.StateGame.getGame();
  ctx.StateGame.addPoints(game.team1.id, 40);
  const savedRaw = ctx.localStorage.getItem(ctx.Storage.KEYS.ACTIVE_GAME);
  assert(!!savedRaw, 'la partida activa debe persistirse automáticamente');

  // Simula reabrir la app: nuevo contexto, mismos datos de localStorage.
  const ctx2 = freshContext();
  ctx2.localStorage.store = ctx.localStorage.store;
  ctx2.StateGame.init();
  assert(ctx2.StateGame.hasActiveGame() === true, 'debe detectar partida activa al reabrir');
  assert(ctx2.StateGame.scores().team1 === 40, 'no debe perder los puntos guardados');
});

test('Abandonar partida la archiva sin ganador', () => {
  const ctx = freshContext();
  setupBasicGame(ctx);
  ctx.StateGame.abandonActiveGame();
  assert(ctx.StateGame.hasActiveGame() === false, 'no debe quedar partida activa');
  const hist = ctx.StateGame.history();
  assert(hist.length === 1 && hist[0].status === 'abandoned', 'debe guardarse como abandonada en el historial');
});

test('Cervezas: regla "por equipo" genera una sola deuda de equipo', () => {
  const ctx = freshContext();
  const game = setupBasicGame(ctx, 100, true, { amountPerLoss: 2, distribution: 'equipo' });
  ctx.StateGame.addPoints(game.team1.id, 100);
  const finished = ctx.StateGame.getGame();
  const beerResult = ctx.StateBeer.generateDebtsForGame(finished);
  assert(beerResult.totalQuantity === 2, 'la deuda total debe ser 2');
  const debts = ctx.StateBeer.debtsForGame(finished.id);
  assert(debts.length === 1, 'debe crearse exactamente 1 deuda para la regla "equipo"');
  assert(debts[0].debtorType === 'team' && debts[0].debtorId === finished.team2.id, 'el equipo perdedor debe ser el deudor');
});

test('Cervezas: regla "por jugador" genera una deuda por cada perdedor', () => {
  const ctx = freshContext();
  const game = setupBasicGame(ctx, 100, true, { amountPerLoss: 1, distribution: 'jugador' });
  ctx.StateGame.addPoints(game.team1.id, 100);
  const finished = ctx.StateGame.getGame();
  const beerResult = ctx.StateBeer.generateDebtsForGame(finished);
  assert(beerResult.totalQuantity === 2, 'con 2 jugadores perdedores x 1 c/u = 2 en total');
  const debts = ctx.StateBeer.debtsForGame(finished.id);
  assert(debts.length === 2, 'debe crearse 1 deuda por cada jugador perdedor');
  assert(debts.every((d) => d.debtorType === 'player'), 'cada deuda debe ser de un jugador, no de un equipo');
});

test('Cervezas: liquidación total y parcial', () => {
  const ctx = freshContext();
  const game = setupBasicGame(ctx, 100, true, { amountPerLoss: 3, distribution: 'equipo' });
  ctx.StateGame.addPoints(game.team1.id, 100);
  const finished = ctx.StateGame.getGame();
  ctx.StateBeer.generateDebtsForGame(finished);
  const debt = ctx.StateBeer.pendingDebts()[0];

  ctx.StateBeer.payDebt(debt.id, 1);
  const afterPartial = ctx.StateBeer.debtById(debt.id);
  assert(afterPartial.remaining === 2, 'debe quedar remaining=2 tras pagar 1 de 3');
  assert(afterPartial.status === 'partial', 'status debe ser partial');

  ctx.StateBeer.payDebt(debt.id, 2);
  const afterFull = ctx.StateBeer.debtById(debt.id);
  assert(afterFull.remaining === 0, 'debe quedar remaining=0 tras pagar el resto');
  assert(afterFull.status === 'paid', 'status debe ser paid');
  assert(ctx.StateBeer.allPayments().length === 2, 'debe haber 2 pagos en el historial');
});

test('Cervezas: consumo personal es independiente de las deudas (sección 42)', () => {
  const ctx = freshContext();
  const juan = ctx.Players.getOrCreate('Juan');
  ctx.StateBeer.addEntry(juan.id, 5, null, '');
  const stats = ctx.Stats.playerStats(juan.id);
  assert(stats.consumidas === 5, 'consumidas debe reflejar el consumo personal');
  assert(stats.ganadas === 0 && stats.debidas === 0, 'ganadas/debidas no deben verse afectadas por el consumo personal');
});

test('Estadísticas: partidas, victorias y porcentaje por jugador', () => {
  const ctx = freshContext();
  const game1 = setupBasicGame(ctx, 50);
  ctx.StateGame.addPoints(game1.team1.id, 50); // team1 (Juan+José) gana
  ctx.StateGame.finalizeAndArchive();

  const p1 = ctx.Players.all().find((p) => p.name === 'Juan');
  const p3 = ctx.Players.all().find((p) => p.name === 'María');
  const game2 = ctx.StateGame.newGame({
    team1Name: 'Los Tigres', team2Name: 'Los Leones',
    player1Id: p1.id, player2Id: ctx.Players.all().find((p) => p.name === 'José').id,
    player3Id: p3.id, player4Id: ctx.Players.all().find((p) => p.name === 'Estefanía').id,
    targetScore: 50, beerEnabled: false, beerRule: ctx.Models.defaultBeerRule(),
  });
  ctx.StateGame.addPoints(game2.team2.id, 50); // esta vez pierde Juan
  ctx.StateGame.finalizeAndArchive();

  const juanStats = ctx.Stats.playerStats(p1.id);
  assert(juanStats.partidas === 2, `Juan debería tener 2 partidas, tiene ${juanStats.partidas}`);
  assert(juanStats.victorias === 1, `Juan debería tener 1 victoria, tiene ${juanStats.victorias}`);
  assert(juanStats.porcentaje === 50, `porcentaje debería ser 50, es ${juanStats.porcentaje}`);
});

test('Fecha y hora se registran automáticamente', () => {
  const ctx = freshContext();
  const before = Date.now();
  const game = setupBasicGame(ctx);
  assert(game.createdAt >= before, 'createdAt debe registrarse automáticamente');
  ctx.StateGame.addPoints(game.team1.id, 10);
  const entry = ctx.StateGame.getGame().entries[0];
  assert(entry.timestamp >= before, 'cada anotación debe tener timestamp automático');
});

test('Validación: nombres vacíos y puntos inválidos se rechazan', () => {
  const ctx = freshContext();
  const game = setupBasicGame(ctx);
  assert(ctx.StateGame.addPoints(game.team1.id, 0) === false, 'no debe aceptar 0 puntos');
  assert(ctx.StateGame.addPoints(game.team1.id, 'abc') === false, 'no debe aceptar puntos no numéricos');
  assert(ctx.StateGame.updateTeamName(game.team1.id, '') === false, 'no debe aceptar nombre vacío');
});

// ---------------- Helpers ----------------

function setupBasicGame(ctx, targetScore, beerEnabled, beerRule) {
  const p1 = ctx.Players.getOrCreate('Juan');
  const p2 = ctx.Players.getOrCreate('José');
  const p3 = ctx.Players.getOrCreate('María');
  const p4 = ctx.Players.getOrCreate('Estefanía');
  return ctx.StateGame.newGame({
    team1Name: 'Los Tigres', team2Name: 'Los Leones',
    player1Id: p1.id, player2Id: p2.id, player3Id: p3.id, player4Id: p4.id,
    targetScore: targetScore || 100,
    beerEnabled: !!beerEnabled,
    beerRule: beerRule || ctx.Models.defaultBeerRule(),
  });
}

// ================= RESUMEN =================
console.log(`\n${'='.repeat(50)}`);
console.log(`✓ ${pass} pruebas pasaron, ✗ ${fail} fallaron`);
console.log('='.repeat(50));
process.exit(fail > 0 ? 1 : 0);
