/**
 * FamaClub Records — Service Worker
 * Estrategia cache-first sobre el "app shell". Sin sincronización en
 * segundo plano ni llamadas periódicas: intencional, para batería.
 */

const CACHE_NAME = 'famaclub-records-v2';
const APP_SHELL = [
  './', './index.html', './manifest.json', './css/styles.css',
  './js/models.js', './js/storage.js', './js/settings.js', './js/players.js',
  './js/state-game.js', './js/state-beer.js', './js/stats.js',
  './js/feedback.js', './js/theme.js', './js/phrases.js', './js/share.js',
  './js/ui-common.js', './js/ui-home.js', './js/ui-newgame.js', './js/ui-board.js',
  './js/ui-victory.js', './js/ui-beer.js', './js/ui-stats.js', './js/ui-history.js',
  './js/ui-settings.js', './js/main.js',
  './icons/icon-64.png', './icons/icon-72.png', './icons/icon-96.png', './icons/icon-128.png',
  './icons/icon-144.png', './icons/icon-152.png', './icons/icon-192.png',
  './icons/icon-192-maskable.png', './icons/icon-384.png', './icons/icon-512.png',
  './icons/icon-512-maskable.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          if (response && response.status === 200 && event.request.url.startsWith(self.location.origin)) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return response;
        })
        .catch(() => cached);
    })
  );
});
