/**
 * FamaClub Records — Marcador
 * Controla el board normal y el "Modo mesa" (misma partida, UI mínima),
 * y es el único punto donde el marcador de puntos "avisa" al sistema de
 * cervezas que hay un ganador (una sola vez por partida).
 */

const UIBoard = (() => {
  let pointsFlow = { mode: 'add', teamId: null, entryId: null, digits: '', fixedPoints: null };
  let renameTeamId = null;
  let victoryHandledForGameId = null;

  function playerName(id) {
    const p = Players.byId(id);
    return p ? p.name : '—';
  }

  function render() {
    const game = StateGame.getGame();
    if (!game) return;
    const s = StateGame.scores();

    $('#board-target').textContent = game.targetScore;
    $('#name-team1').textContent = game.team1.name.toUpperCase();
    $('#name-team2').textContent = game.team2.name.toUpperCase();
    $('#players-team1').textContent = game.team1.playerIds.map(playerName).join(' • ');
    $('#players-team2').textContent = game.team2.playerIds.map(playerName).join(' • ');
    $('#score-team1').textContent = s.team1;
    $('#score-team2').textContent = s.team2;

    const rem1 = Math.max(game.targetScore - s.team1, 0);
    const rem2 = Math.max(game.targetScore - s.team2, 0);
    $('#remaining-team1').textContent = rem1 === 0 ? '¡Meta alcanzada!' : `Faltan ${rem1}`;
    $('#remaining-team2').textContent = rem2 === 0 ? '¡Meta alcanzada!' : `Faltan ${rem2}`;

    const card1 = $('#card-team1'), card2 = $('#card-team2');
    card1.classList.remove('leading'); card2.classList.remove('leading');
    $('#trophy-team1').style.display = 'none'; $('#trophy-team2').style.display = 'none';
    if (s.team1 !== s.team2 && (s.team1 > 0 || s.team2 > 0)) {
      if (s.team1 > s.team2) { card1.classList.add('leading'); $('#trophy-team1').style.display = 'inline'; }
      else { card2.classList.add('leading'); $('#trophy-team2').style.display = 'inline'; }
    }

    const last = game.entries[game.entries.length - 1];
    if (last) {
      const team = last.teamId === game.team1.id ? game.team1 : game.team2;
      const sign = last.points >= 0 ? '+' : '';
      $('#last-entry').innerHTML = `<b>${UICommon.escapeHtml(team.name)}</b> ${sign}${last.points}`;
    } else {
      $('#last-entry').textContent = 'Registra el primer punto para comenzar.';
    }

    $('#btn-undo').disabled = !StateGame.canUndo();
    $('#btn-redo').disabled = !StateGame.canRedo();

    renderTableMode();
  }

  function renderTableMode() {
    const game = StateGame.getGame();
    if (!game) return;
    const s = StateGame.scores();
    $('#tm-name1').textContent = game.team1.name.toUpperCase();
    $('#tm-name2').textContent = game.team2.name.toUpperCase();
    $('#tm-score1').textContent = s.team1;
    $('#tm-score2').textContent = s.team2;
    $('#btn-tm-undo').disabled = !StateGame.canUndo();
  }

  // ---------------- Flujo de puntos ----------------

  function openQuickAdd(points) {
    pointsFlow = { mode: 'quick', teamId: null, entryId: null, digits: '', fixedPoints: points };
    $('#points-modal-title').textContent = '¿Quién recibió los puntos?';
    $('#points-team-choice').style.display = 'flex';
    $('#points-keypad-section').style.display = 'none';
    fillTeamChoiceLabels();
    UICommon.openModal('modal-points');
  }

  function openOtherPoints() {
    pointsFlow = { mode: 'add', teamId: null, entryId: null, digits: '', fixedPoints: null };
    $('#points-modal-title').textContent = '¿A qué equipo?';
    $('#points-team-choice').style.display = 'flex';
    $('#points-keypad-section').style.display = 'none';
    fillTeamChoiceLabels();
    UICommon.openModal('modal-points');
  }

  function fillTeamChoiceLabels() {
    const game = StateGame.getGame();
    $('[data-choice-team="team1"]').textContent = game.team1.name.toUpperCase();
    $('[data-choice-team="team2"]').textContent = game.team2.name.toUpperCase();
  }

  function openEditEntry(entry) {
    pointsFlow = { mode: 'edit', teamId: entry.teamId, entryId: entry.id, digits: String(Math.abs(entry.points)), fixedPoints: null };
    $('#points-modal-title').textContent = 'Editar puntos';
    $('#points-team-choice').style.display = 'none';
    $('#points-keypad-section').style.display = 'block';
    $('#keypad-display').textContent = pointsFlow.digits || '0';
    $('#btn-confirm-points').textContent = 'Guardar';
    UICommon.openModal('modal-points');
  }

  function bindPointsModal() {
    $$('[data-choice-team]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const game = StateGame.getGame();
        const teamId = btn.dataset.choiceTeam === 'team1' ? game.team1.id : game.team2.id;
        pointsFlow.teamId = teamId;

        if (pointsFlow.mode === 'quick') {
          StateGame.addPoints(teamId, pointsFlow.fixedPoints);
          Feedback.pointAdded();
          UICommon.closeModal('modal-points');
          refreshAfterScoreChange();
          return;
        }
        $('#points-modal-title').textContent = '¿Cuántos puntos?';
        $('#points-team-choice').style.display = 'none';
        $('#points-keypad-section').style.display = 'block';
        $('#keypad-display').textContent = '0';
        $('#btn-confirm-points').textContent = 'Agregar';
        pointsFlow.digits = '';
        Feedback.tap();
      });
    });

    $$('.keypad button').forEach((key) => {
      key.addEventListener('click', () => {
        const k = key.dataset.key;
        if (k === 'clear') pointsFlow.digits = '';
        else if (k === 'back') pointsFlow.digits = pointsFlow.digits.slice(0, -1);
        else if (pointsFlow.digits.length < 4) pointsFlow.digits += k;
        $('#keypad-display').textContent = pointsFlow.digits || '0';
        Feedback.tap();
      });
    });

    let submitting = false;
    $('#btn-confirm-points').addEventListener('click', () => {
      if (submitting) return;
      const points = Number(pointsFlow.digits);
      if (!points || points <= 0) { UICommon.toast('Ingresa un número mayor a cero'); return; }
      submitting = true;
      setTimeout(() => (submitting = false), 400);

      if (pointsFlow.mode === 'add') {
        StateGame.addPoints(pointsFlow.teamId, points);
        Feedback.pointAdded();
      } else if (pointsFlow.mode === 'edit') {
        StateGame.editEntry(pointsFlow.entryId, points);
        UICommon.toast('Anotación actualizada');
      }
      UICommon.closeModal('modal-points');
      refreshAfterScoreChange();
    });
  }

  function refreshAfterScoreChange() {
    render();
    if ($('#screen-game-history').classList.contains('active')) renderGameHistory();
    maybeHandleWin();
  }

  // ---------------- Ganador → sistema de cervezas ----------------

  function maybeHandleWin() {
    const game = StateGame.getGame();
    if (!game || game.status !== 'finished') return;
    if (victoryHandledForGameId === game.id) return;

    // Idempotente respecto a los datos persistidos (no solo a esta sesión):
    // si beerResult ya existe, la deuda ya se generó antes y no debe duplicarse.
    if (game.beerEnabled && !game.beerResult && game.beerRule.distribution === 'personalizado') {
      openCustomBeerAssignment(game);
      return; // se completa en confirmCustomBeer()
    }
    finalizeVictory(game);
  }

  function finalizeVictory(game, customAssignments) {
    victoryHandledForGameId = game.id;
    if (game.beerEnabled && !game.beerResult) {
      const beerResult = StateBeer.generateDebtsForGame(game, customAssignments);
      StateGame.attachBeerResult(beerResult);
    }
    Feedback.win();
    UIVictory.render();
    UICommon.showScreen('screen-victory');
  }

  // Se llama una sola vez al abrir la app: si quedó una partida "finished"
  // sin archivar (la app se cerró justo en la pantalla de victoria), la
  // retoma silenciosamente sin repetir sonido ni regenerar cervezas.
  function resumeIfFinishedUnarchived() {
    const game = StateGame.getGame();
    if (!game || game.status !== 'finished') return false;
    victoryHandledForGameId = game.id;
    if (game.beerEnabled && !game.beerResult && game.beerRule.distribution !== 'personalizado') {
      const beerResult = StateBeer.generateDebtsForGame(game);
      StateGame.attachBeerResult(beerResult);
    }
    UIVictory.render();
    UICommon.showScreen('screen-victory');
    return true;
  }

  function openCustomBeerAssignment(game) {
    const loser = Models.otherTeam(game, game.winnerTeamId);
    const list = $('#custom-beer-list');
    list.innerHTML = '';
    loser.playerIds.forEach((playerId) => {
      const row = document.createElement('div');
      row.className = 'field';
      row.innerHTML = `
        <label>${UICommon.escapeHtml(playerName(playerId))} debe</label>
        <input type="number" min="0" value="${game.beerRule.amountPerLoss}" data-debtor="${playerId}" />
      `;
      list.appendChild(row);
    });
    UICommon.openModal('modal-custom-beer');
  }

  function bindCustomBeerModal() {
    $('#btn-confirm-custom-beer').addEventListener('click', () => {
      const game = StateGame.getGame();
      const assignments = $$('#custom-beer-list input').map((input) => ({
        debtorId: input.dataset.debtor,
        quantity: Number(input.value) || 0,
      }));
      UICommon.closeModal('modal-custom-beer');
      finalizeVictory(game, assignments);
    });
  }

  // ---------------- Menú / renombrar / reiniciar / abandonar ----------------

  function openRename(team) {
    renameTeamId = team.id;
    $('#rename-input').value = team.name;
    UICommon.openModal('modal-rename');
    setTimeout(() => $('#rename-input').focus(), 50);
  }

  function bindRenameModal() {
    $('#rename-cancel').addEventListener('click', () => UICommon.closeModal('modal-rename'));
    $('#rename-accept').addEventListener('click', () => {
      const ok = StateGame.updateTeamName(renameTeamId, $('#rename-input').value);
      if (ok) { UICommon.closeModal('modal-rename'); render(); UICommon.toast('Nombre actualizado'); }
      else UICommon.toast('El nombre no puede estar vacío');
    });
  }

  function bindMenu() {
    $('#btn-board-menu').addEventListener('click', () => UICommon.openModal('modal-board-menu'));
    $('#menu-cancel').addEventListener('click', () => UICommon.closeModal('modal-board-menu'));
    $('#menu-rename-team1').addEventListener('click', () => { UICommon.closeModal('modal-board-menu'); openRename(StateGame.getGame().team1); });
    $('#menu-rename-team2').addEventListener('click', () => { UICommon.closeModal('modal-board-menu'); openRename(StateGame.getGame().team2); });
    $('#menu-restart').addEventListener('click', () => {
      UICommon.closeModal('modal-board-menu');
      UICommon.showConfirm('Reiniciar partida', 'Los marcadores volverán a cero y el historial de esta partida se perderá.', () => {
        StateGame.restartGame();
        victoryHandledForGameId = null;
        render();
        UICommon.toast('Partida reiniciada');
      });
    });
    $('#menu-abandon').addEventListener('click', () => {
      UICommon.closeModal('modal-board-menu');
      UICommon.showConfirm('Abandonar partida', 'Se guardará como partida abandonada en el historial, sin ganador.', () => {
        StateGame.abandonActiveGame();
        UICommon.showScreen('screen-home');
        UIHome.render();
      });
    });
  }

  // ---------------- Cuadrícula de rondas (partida actual) ----------------

  function renderGameHistory() {
    const game = StateGame.getGame();
    if (!game) return;
    const s = StateGame.scores();
    $('#gh-name1').textContent = game.team1.name; $('#gh-score1').textContent = s.team1;
    $('#gh-name2').textContent = game.team2.name; $('#gh-score2').textContent = s.team2;

    UICommon.renderRoundsGrid($('#game-history-list'), game, (entries, teamId, round) => {
      if (entries.length === 0) return;
      if (entries.length === 1) { openEntryActions(entries[0]); return; }
      UICommon.showActionSheet(`Ronda ${round}`, entries.map((entry) => ({
        label: `${entry.points >= 0 ? '+' : ''}${entry.points} — editar/eliminar`,
        action: () => openEntryActions(entry),
      })));
    });
  }

  function openEntryActions(entry) {
    UICommon.showActionSheet(`${entry.points >= 0 ? '+' : ''}${entry.points} pts`, [
      { label: 'Editar', action: () => openEditEntry(entry) },
      { label: 'Eliminar', danger: true, action: () => {
          UICommon.showConfirm('Eliminar anotación', 'El marcador se recalculará automáticamente.', () => {
            StateGame.deleteEntry(entry.id);
            renderGameHistory();
            render();
            UICommon.toast('Anotación eliminada');
          });
        } },
    ]);
  }

  // ---------------- Bind general ----------------

  function bind() {
    $$('.quickadd-chip[data-quick]').forEach((btn) => {
      btn.addEventListener('click', () => (btn.dataset.quick === 'other' ? openOtherPoints() : openQuickAdd(Number(btn.dataset.quick))));
    });
    $$('.quickadd-chip[data-quick-tm]').forEach((btn) => {
      btn.addEventListener('click', () => (btn.dataset.quickTm === 'other' ? openOtherPoints() : openQuickAdd(Number(btn.dataset.quickTm))));
    });

    $('#btn-undo').addEventListener('click', () => { if (StateGame.undo()) { Feedback.undo(); UICommon.toast('Acción deshecha'); render(); } });
    $('#btn-redo').addEventListener('click', () => { if (StateGame.redo()) { Feedback.tap(); UICommon.toast('Acción rehecha'); render(); } });
    $('#btn-tm-undo').addEventListener('click', () => { if (StateGame.undo()) { Feedback.undo(); render(); } });

    $('#btn-ver-historial-partida').addEventListener('click', () => { renderGameHistory(); UICommon.showScreen('screen-game-history'); });

    $('#btn-table-mode').addEventListener('click', () => { renderTableMode(); UICommon.showScreen('screen-table-mode'); });
    $('#btn-exit-table-mode').addEventListener('click', () => UICommon.showScreen('screen-board'));

    bindPointsModal();
    bindRenameModal();
    bindMenu();
    bindCustomBeerModal();
  }

  return { render, renderGameHistory, bind, playerName, resumeIfFinishedUnarchived };
})();
