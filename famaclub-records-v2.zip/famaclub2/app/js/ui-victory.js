/**
 * FamaClub Records — Victoria
 */

const UIVictory = (() => {
  function render() {
    const game = StateGame.getGame();
    if (!game) return;
    const s = StateGame.scores();
    const winnerIsTeam1 = game.winnerTeamId === game.team1.id;
    const winner = winnerIsTeam1 ? game.team1 : game.team2;

    $('#victory-title').textContent = `¡${winner.name.toUpperCase()} GANÓ!`;
    $('#victory-name1').textContent = game.team1.name;
    $('#victory-players1').textContent = game.team1.playerIds.map(UIBoard.playerName).join(' • ');
    $('#victory-score1').textContent = s.team1;
    $('#victory-name2').textContent = game.team2.name;
    $('#victory-players2').textContent = game.team2.playerIds.map(UIBoard.playerName).join(' • ');
    $('#victory-score2').textContent = s.team2;
    $('#victory-card1').classList.toggle('winner', winnerIsTeam1);
    $('#victory-card2').classList.toggle('winner', !winnerIsTeam1);

    const phrase = Phrases.forWin(winner.name);
    $('#victory-phrase').textContent = phrase || '';

    const box = $('#victory-beer-box');
    if (game.beerEnabled && game.beerResult && game.beerResult.totalQuantity > 0) {
      const loser = Models.otherTeam(game, game.winnerTeamId);
      box.style.display = 'block';
      box.innerHTML = `🍺 <b>${UICommon.escapeHtml(loser.name)}</b> debe(n) <b>${game.beerResult.totalQuantity} 🍺</b> a <b>${UICommon.escapeHtml(winner.name)}</b>`;
    } else {
      box.style.display = 'none';
    }
  }

  function bind() {
    $('#btn-victory-new').addEventListener('click', () => {
      StateGame.finalizeAndArchive();
      UINewGame.render();
      UICommon.showScreen('screen-new-game');
    });
    $('#btn-victory-home').addEventListener('click', () => {
      StateGame.finalizeAndArchive();
      UICommon.showScreen('screen-home');
      UIHome.render();
    });
    $('#btn-victory-share').addEventListener('click', async () => {
      const game = StateGame.getGame();
      if (!game) return;
      const result = await Share.shareGame(game, UIBoard.playerName);
      if (result.method === 'clipboard') UICommon.toast('Resultado copiado al portapapeles');
      else if (!result.ok && result.method === 'unsupported') UICommon.toast('Tu navegador no permite compartir directamente');
    });
  }

  return { render, bind };
})();
