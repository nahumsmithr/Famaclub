/**
 * FamaClub Records — main
 * Cero llamadas de red. Todo lo necesario para jugar ya está en el dispositivo.
 */

(function bootstrap() {
  // Orden importa: Settings/Players/StateGame/StateBeer antes que la UI.
  AppSettings.init();
  Players.init();
  StateGame.init();
  StateBeer.init();
  Theme.apply();

  UICommon.init();
  UIHome.bind();
  UINewGame.bind();
  UIBoard.bind();
  UIVictory.bind();
  UIBeer.bind();
  UIStats.bind();
  UIHistory.bind();
  UISettings.bind();

  // Si la app se cerró justo en la pantalla de victoria (antes de archivar
  // la partida), la retomamos ahí mismo en vez de perderla silenciosamente.
  const resumed = UIBoard.resumeIfFinishedUnarchived();
  if (!resumed) UIHome.render();

  // Refresca cada pestaña justo al entrar, para que los datos nunca
  // se vean desactualizados si cambiaron desde otra pantalla.
  document.addEventListener('nav-changed', (e) => {
    switch (e.detail) {
      case 'screen-home': UIHome.render(); break;
      case 'screen-board':
        if (StateGame.hasActiveGame()) UIBoard.render();
        else { UICommon.showScreen('screen-home'); UIHome.render(); UICommon.toast('No hay ninguna partida activa'); }
        break;
      case 'screen-beer': UIBeer.render(); break;
      case 'screen-stats': UIStats.render(); break;
      case 'screen-saved-games': UIHistory.render(); break;
      case 'screen-settings': UISettings.render(); break;
    }
  });

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (AppSettings.get().theme === 'auto') Theme.apply();
  });

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('service-worker.js').catch((err) => {
        console.warn('No se pudo registrar el Service Worker:', err);
      });
    });
  }
})();
