/**
 * FamaClub Records — Modelos (v2)
 * Objetos planos, serializables a JSON. Sin lógica de negocio aquí:
 * eso vive en state-game.js / state-beer.js / stats.js.
 */

const Models = (() => {
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  // ---------------- Jugadores ----------------

  function createPlayer(name) {
    return { id: uid(), name: (name || '').trim(), createdAt: Date.now() };
  }

  // ---------------- Equipo (vive dentro de un Game) ----------------

  function createTeam(name, playerIds) {
    return { id: uid(), name: (name || '').trim(), playerIds: playerIds.slice(0, 2) };
  }

  // ---------------- Puntuación ----------------

  function createEntry(teamId, points, round) {
    return { id: uid(), teamId, points: Number(points), round, timestamp: Date.now() };
  }

  // ---------------- Partida ----------------

  function defaultBeerRule() {
    return {
      amountPerLoss: 2,
      distribution: 'equipo', // 'equipo' | 'jugador' | 'personalizado'
    };
  }

  function createGame({ team1, team2, targetScore, beerEnabled, beerRule }) {
    const now = Date.now();
    return {
      id: uid(),
      team1, // { id, name, playerIds }
      team2,
      targetScore: Number(targetScore) || 100,
      entries: [],
      beerEnabled: !!beerEnabled,
      beerRule: beerRule || defaultBeerRule(),
      status: 'active', // 'active' | 'finished' | 'abandoned'
      winnerTeamId: null,
      beerResult: null, // se llena al finalizar, ver state-beer.js
      createdAt: now,
      startedAt: now,
      finishedAt: null,
    };
  }

  // ---------------- Cervezas ----------------

  function createBeerEntry(playerId, quantity, gameId, note) {
    return {
      id: uid(),
      playerId,
      quantity: Number(quantity),
      gameId: gameId || null,
      note: (note || '').trim(),
      timestamp: Date.now(),
    };
  }

  function createBeerDebt({ debtorType, debtorId, creditorType, creditorId, quantity, gameId }) {
    return {
      id: uid(),
      debtorType, // 'player' | 'team'
      debtorId,
      creditorType,
      creditorId,
      quantity: Number(quantity),
      remaining: Number(quantity),
      gameId: gameId || null,
      createdAt: Date.now(),
      status: 'pending', // 'pending' | 'partial' | 'paid'
    };
  }

  function createBeerPayment({ debtId, debtorId, creditorId, quantity, gameId }) {
    return {
      id: uid(),
      debtId,
      debtorId,
      creditorId,
      quantity: Number(quantity),
      gameId: gameId || null,
      timestamp: Date.now(),
    };
  }

  // ---------------- Configuración ----------------

  function defaultSettings() {
    return {
      defaultTargetScore: 100,
      beerEnabledDefault: true,
      beerRuleDefault: defaultBeerRule(),
      funnyPhrases: true,
      sound: true,
      vibration: true,
      confirmEndGame: false,
      theme: 'auto',
      background: {
        type: 'default',
        color: '#0f1720',
        gradientFrom: '#0f1720',
        gradientTo: '#1c2a3a',
        image: null,
        opacity: 1,
        overlayOpacity: 0.55,
      },
    };
  }

  // ---------------- Derivación (SIEMPRE a partir de entries) ----------------

  function scoreFor(game, teamId) {
    return game.entries.filter((e) => e.teamId === teamId).reduce((s, e) => s + e.points, 0);
  }

  function currentRound(game) {
    if (game.entries.length === 0) return 1;
    return game.entries[game.entries.length - 1].round;
  }

  function checkWinner(game) {
    const s1 = scoreFor(game, game.team1.id);
    const s2 = scoreFor(game, game.team2.id);
    if (s1 >= game.targetScore || s2 >= game.targetScore) {
      if (s1 === s2) return null;
      return s1 > s2 ? game.team1.id : game.team2.id;
    }
    return null;
  }

  function otherTeam(game, teamId) {
    return game.team1.id === teamId ? game.team2 : game.team1;
  }

  return {
    uid,
    createPlayer,
    createTeam,
    createEntry,
    createGame,
    defaultBeerRule,
    createBeerEntry,
    createBeerDebt,
    createBeerPayment,
    defaultSettings,
    scoreFor,
    currentRound,
    checkWinner,
    otherTeam,
  };
})();
