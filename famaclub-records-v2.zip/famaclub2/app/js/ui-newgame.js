/**
 * FamaClub Records — Nueva partida
 */

const UINewGame = (() => {
  let selected = { p1: null, p2: null, p3: null, p4: null };
  let selectedTarget = 100;
  let beerEnabled = true;
  let beerAmount = 2;
  let beerDistribution = 'equipo';
  let activeSlot = null;

  const SLOT_LABELS = { p1: 'Jugador 1', p2: 'Jugador 2', p3: 'Jugador 3', p4: 'Jugador 4' };

  function render() {
    const settings = AppSettings.get();
    selected = { p1: null, p2: null, p3: null, p4: null };
    selectedTarget = settings.defaultTargetScore || 100;
    beerEnabled = !!settings.beerEnabledDefault;
    beerAmount = settings.beerRuleDefault.amountPerLoss || 2;
    beerDistribution = settings.beerRuleDefault.distribution || 'equipo';

    $('#input-team1-name').value = '';
    $('#input-team2-name').value = '';
    $$('.player-slot').forEach((btn) => { btn.textContent = `+ ${SLOT_LABELS[btn.dataset.slot]}`; btn.classList.remove('filled'); });

    $('#input-target-custom').style.display = 'none';
    $('#input-target-custom').value = '';
    $$('#target-chip-row .chip').forEach((c) => c.classList.toggle('selected', Number(c.dataset.target) === selectedTarget));
    if (!$('#target-chip-row .chip.selected')) {
      $('#target-chip-row .chip[data-target="custom"]').classList.add('selected');
      $('#input-target-custom').style.display = 'block';
      $('#input-target-custom').value = selectedTarget;
    }

    updateBeerToggleUI();
    updateBeerAmountUI();
    updateBeerDistributionUI();
  }

  function updateBeerToggleUI() {
    $('#beer-toggle-yes').classList.toggle('selected', beerEnabled);
    $('#beer-toggle-no').classList.toggle('selected', !beerEnabled);
    $('#beer-rule-config').style.display = beerEnabled ? 'block' : 'none';
  }
  function updateBeerAmountUI() {
    $$('#beer-amount-row .chip').forEach((c) => c.classList.toggle('selected', c.dataset.amount === String(beerAmount)));
    if (!$('#beer-amount-row .chip.selected')) {
      $('#beer-amount-row .chip[data-amount="custom"]').classList.add('selected');
      $('#input-beer-amount-custom').style.display = 'block';
      $('#input-beer-amount-custom').value = beerAmount;
    } else {
      $('#input-beer-amount-custom').style.display = 'none';
    }
  }
  function updateBeerDistributionUI() {
    $$('#beer-distribution-row .chip').forEach((c) => c.classList.toggle('selected', c.dataset.dist === beerDistribution));
    const hints = {
      equipo: 'El equipo perdedor debe la cantidad completa al equipo ganador.',
      jugador: 'Cada jugador del equipo perdedor debe la cantidad configurada.',
      personalizado: 'Al terminar la partida podrás decidir quién debe cuánto.',
    };
    $('#beer-distribution-hint').textContent = hints[beerDistribution] || '';
  }

  // ---------------- Selector de jugador ----------------

  function openPlayerPicker(slot) {
    activeSlot = slot;
    $('#player-search').value = '';
    renderPlayerPickerList('');
    UICommon.openModal('modal-player-picker');
    setTimeout(() => $('#player-search').focus(), 60);
  }

  function renderPlayerPickerList(query) {
    const list = $('#player-picker-list');
    list.innerHTML = '';
    const q = query.trim().toLowerCase();
    const taken = Object.values(selected).filter((p) => p && (!activeSlot || selected[activeSlot] !== p)).map((p) => p.id);
    const players = Players.all().filter((p) => p.name.toLowerCase().includes(q));

    players.forEach((p) => {
      const row = document.createElement('button');
      row.className = 'player-row';
      row.textContent = p.name;
      if (taken.includes(p.id)) { row.disabled = true; row.classList.add('disabled'); row.textContent += ' (ya en la partida)'; }
      row.addEventListener('click', () => choosePlayer(p));
      list.appendChild(row);
    });

    const exact = players.some((p) => p.name.toLowerCase() === q);
    $('#btn-create-player-inline').style.display = q && !exact ? 'block' : 'none';
    $('#btn-create-player-inline').textContent = `+ Crear "${query.trim()}"`;
  }

  function choosePlayer(player) {
    selected[activeSlot] = player;
    const btn = $(`.player-slot[data-slot="${activeSlot}"]`);
    btn.textContent = player.name;
    btn.classList.add('filled');
    UICommon.closeModal('modal-player-picker');
    Feedback.tap();
  }

  function bindPlayerPicker() {
    $('#player-search').addEventListener('input', (e) => renderPlayerPickerList(e.target.value));
    $('#btn-create-player-inline').addEventListener('click', () => {
      const name = $('#player-search').value.trim();
      if (!name) return;
      const player = Players.getOrCreate(name);
      choosePlayer(player);
    });
  }

  // ---------------- Bind principal ----------------

  function bind() {
    $$('.player-slot').forEach((btn) => btn.addEventListener('click', () => openPlayerPicker(btn.dataset.slot)));
    bindPlayerPicker();

    $$('#target-chip-row .chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        $$('#target-chip-row .chip').forEach((c) => c.classList.remove('selected'));
        chip.classList.add('selected');
        Feedback.tap();
        if (chip.dataset.target === 'custom') {
          $('#input-target-custom').style.display = 'block';
          $('#input-target-custom').focus();
        } else {
          $('#input-target-custom').style.display = 'none';
          selectedTarget = Number(chip.dataset.target);
        }
      });
    });
    $('#input-target-custom').addEventListener('input', (e) => { selectedTarget = Number(e.target.value) || 0; });

    $('#beer-toggle-yes').addEventListener('click', () => { beerEnabled = true; updateBeerToggleUI(); Feedback.tap(); });
    $('#beer-toggle-no').addEventListener('click', () => { beerEnabled = false; updateBeerToggleUI(); Feedback.tap(); });

    $$('#beer-amount-row .chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        Feedback.tap();
        if (chip.dataset.amount === 'custom') {
          $('#input-beer-amount-custom').style.display = 'block';
          $('#input-beer-amount-custom').focus();
          $$('#beer-amount-row .chip').forEach((c) => c.classList.remove('selected'));
          chip.classList.add('selected');
        } else {
          beerAmount = Number(chip.dataset.amount);
          updateBeerAmountUI();
        }
      });
    });
    $('#input-beer-amount-custom').addEventListener('input', (e) => { beerAmount = Number(e.target.value) || 1; });

    $$('#beer-distribution-row .chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        beerDistribution = chip.dataset.dist;
        updateBeerDistributionUI();
        Feedback.tap();
      });
    });

    $('#btn-comenzar-partida').addEventListener('click', startGame);
  }

  function startGame() {
    if (!selected.p1 || !selected.p2 || !selected.p3 || !selected.p4) {
      UICommon.toast('Elige los 4 jugadores para comenzar');
      return;
    }
    const target = selectedTarget > 0 ? selectedTarget : 100;
    const t1 = $('#input-team1-name').value.trim() || `${selected.p1.name} & ${selected.p2.name}`;
    const t2 = $('#input-team2-name').value.trim() || `${selected.p3.name} & ${selected.p4.name}`;

    StateGame.newGame({
      team1Name: t1,
      team2Name: t2,
      player1Id: selected.p1.id,
      player2Id: selected.p2.id,
      player3Id: selected.p3.id,
      player4Id: selected.p4.id,
      targetScore: target,
      beerEnabled,
      beerRule: { amountPerLoss: beerAmount, distribution: beerDistribution },
    });

    Feedback.tap();
    UICommon.showScreen('screen-board');
    UIBoard.render();
  }

  return { render, bind };
})();
