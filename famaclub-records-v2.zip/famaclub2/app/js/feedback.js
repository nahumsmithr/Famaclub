/**
 * FamaClub Records — Feedback (sonido / vibración)
 * Generado con WebAudio, sin archivos de audio: cero peso, cero red.
 */

const Feedback = (() => {
  let audioCtx = null;

  function ctx() {
    if (!audioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) audioCtx = new AC();
    }
    return audioCtx;
  }

  function tone(freq, durationMs, type = 'sine', gain = 0.08) {
    if (!AppSettings.get().sound) return;
    const c = ctx();
    if (!c) return;
    if (c.state === 'suspended') c.resume();
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.value = gain;
    osc.connect(g).connect(c.destination);
    const now = c.currentTime;
    g.gain.setValueAtTime(gain, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + durationMs / 1000);
    osc.start(now);
    osc.stop(now + durationMs / 1000);
  }

  function vibrate(pattern) {
    if (!AppSettings.get().vibration) return;
    if (navigator.vibrate) navigator.vibrate(pattern);
  }

  return {
    pointAdded: () => { tone(660, 90); vibrate(15); },
    beerAdded: () => { tone(500, 80, 'triangle'); vibrate(12); },
    undo: () => { tone(320, 100, 'triangle'); vibrate(10); },
    win: () => {
      tone(523.25, 140);
      setTimeout(() => tone(659.25, 140), 130);
      setTimeout(() => tone(783.99, 260), 260);
      vibrate([40, 60, 40, 60, 120]);
    },
    tap: () => vibrate(8),
  };
})();
