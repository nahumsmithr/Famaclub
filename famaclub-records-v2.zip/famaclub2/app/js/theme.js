/**
 * FamaClub Records — Theme
 * Traduce AppSettings.theme / .background a variables CSS reales.
 * El modo oscuro tiene su propia paleta (no es una simple inversión).
 */

const Theme = (() => {
  function resolvedMode(themeSetting) {
    if (themeSetting === 'auto') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return themeSetting;
  }

  function backgroundCss(bg) {
    if (bg.type === 'color') return bg.color;
    if (bg.type === 'gradient') return `linear-gradient(160deg, ${bg.gradientFrom}, ${bg.gradientTo})`;
    if (bg.type === 'image' && bg.image) return `url("${bg.image}")`;
    return null;
  }

  function overlayCss(bg, themeSetting) {
    const mode = resolvedMode(themeSetting);
    const base = mode === 'light' ? '244,241,234' : '15,23,32';
    return `rgba(${base}, ${bg.overlayOpacity})`;
  }

  function apply() {
    const settings = AppSettings.get();
    const mode = resolvedMode(settings.theme);
    document.documentElement.setAttribute('data-theme', mode);

    const bg = settings.background;
    const bgLayer = document.getElementById('bg-layer');
    const bgOverlay = document.getElementById('bg-overlay');
    if (!bgLayer) return;

    const custom = backgroundCss(bg);
    if (custom) {
      if (bg.type === 'image') {
        bgLayer.style.backgroundImage = custom;
        bgLayer.style.backgroundColor = 'transparent';
      } else {
        bgLayer.style.backgroundImage = 'none';
        bgLayer.style.background = custom;
      }
    } else {
      bgLayer.style.backgroundImage = 'none';
      bgLayer.style.background = mode === 'light' ? '#f4f1ea' : '#0f1720';
    }
    bgLayer.style.opacity = bg.opacity;
    bgOverlay.style.background = overlayCss(bg, settings.theme);

    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', mode === 'light' ? '#f4f1ea' : '#0f1720');
  }

  return { apply, backgroundCss, overlayCss, resolvedMode };
})();
