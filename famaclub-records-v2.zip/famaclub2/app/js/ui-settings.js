/**
 * FamaClub Records — Configuración
 */

const UISettings = (() => {
  const PRESET_COLORS = ['#0f1720', '#f4f1ea', '#1c2a3a', '#2f6f4e', '#c49a5b', '#5b2a86', '#1d3557', '#3a3a3a'];

  function render() {
    const s = AppSettings.get();
    $('#setting-default-target').value = s.defaultTargetScore;
    $('#setting-beer-default').checked = !!s.beerEnabledDefault;
    $('#setting-funny-phrases').checked = !!s.funnyPhrases;
    $('#setting-sound').checked = !!s.sound;
    $('#setting-vibration').checked = !!s.vibration;

    $$('.theme-row .chip').forEach((c) => c.classList.toggle('selected', c.dataset.themeOpt === s.theme));
    $$('.bg-type-row .chip').forEach((c) => c.classList.toggle('selected', c.dataset.bgType === s.background.type));
    renderColorSwatches(s.background.color);
    $('#bg-gradient-from').value = s.background.gradientFrom;
    $('#bg-gradient-to').value = s.background.gradientTo;
    $('#bg-opacity').value = Math.round(s.background.opacity * 100);
    $('#bg-opacity-value').textContent = Math.round(s.background.opacity * 100) + '%';
    $('#bg-overlay').value = Math.round(s.background.overlayOpacity * 100);
    $('#bg-overlay-value').textContent = Math.round(s.background.overlayOpacity * 100) + '%';
    updateBgControlsVisibility(s.background.type);
    updateBgPreview();

    renderPlayersList();
  }

  function renderColorSwatches(selected) {
    const container = $('#bg-color-swatches');
    container.innerHTML = '';
    PRESET_COLORS.forEach((color) => {
      const sw = document.createElement('button');
      sw.className = 'swatch' + (color === selected ? ' selected' : '');
      sw.style.background = color;
      sw.addEventListener('click', () => { AppSettings.update({ background: { color } }); Theme.apply(); render(); });
      container.appendChild(sw);
    });
    const customWrap = document.createElement('label');
    customWrap.className = 'swatch-custom';
    customWrap.innerHTML = `<input type="color" value="${selected}" />`;
    customWrap.querySelector('input').addEventListener('input', (e) => {
      AppSettings.update({ background: { color: e.target.value } });
      Theme.apply(); updateBgPreview();
    });
    container.appendChild(customWrap);
  }

  function updateBgControlsVisibility(type) {
    $('#bg-color-controls').style.display = type === 'color' ? 'block' : 'none';
    $('#bg-gradient-controls').style.display = type === 'gradient' ? 'block' : 'none';
    $('#bg-image-controls').style.display = type === 'image' ? 'block' : 'none';
  }

  function updateBgPreview() {
    const s = AppSettings.get();
    const layer = $('#bg-preview-layer');
    const overlay = $('#bg-preview-overlay');
    layer.style.background = Theme.backgroundCss(s.background) || (Theme.resolvedMode(s.theme) === 'light' ? '#f4f1ea' : '#0f1720');
    layer.style.opacity = s.background.opacity;
    overlay.style.background = Theme.overlayCss(s.background, s.theme);
  }

  function renderPlayersList() {
    const list = $('#settings-players-list');
    list.innerHTML = '';
    Players.all().forEach((p) => {
      const row = document.createElement('div');
      row.className = 'settings-player-row';
      row.innerHTML = `<span>${UICommon.escapeHtml(p.name)}</span><button data-remove="${p.id}">Eliminar</button>`;
      list.appendChild(row);
    });
    Array.from(list.querySelectorAll('[data-remove]')).forEach((btn) => {
      btn.addEventListener('click', () => {
        UICommon.showConfirm('Eliminar jugador', 'No se borrarán sus partidas ni estadísticas pasadas, solo se quitará de la lista rápida.', () => {
          Players.remove(btn.dataset.remove);
          renderPlayersList();
          UICommon.toast('Jugador eliminado');
        });
      });
    });
  }

  function bind() {
    $('#setting-default-target').addEventListener('change', (e) => AppSettings.update({ defaultTargetScore: Math.max(1, Number(e.target.value) || 100) }));
    $('#setting-beer-default').addEventListener('change', (e) => AppSettings.update({ beerEnabledDefault: e.target.checked }));
    $('#setting-funny-phrases').addEventListener('change', (e) => AppSettings.update({ funnyPhrases: e.target.checked }));
    $('#setting-sound').addEventListener('change', (e) => AppSettings.update({ sound: e.target.checked }));
    $('#setting-vibration').addEventListener('change', (e) => AppSettings.update({ vibration: e.target.checked }));

    $$('.theme-row .chip').forEach((chip) => chip.addEventListener('click', () => { AppSettings.update({ theme: chip.dataset.themeOpt }); Theme.apply(); render(); }));
    $$('.bg-type-row .chip').forEach((chip) => chip.addEventListener('click', () => { AppSettings.update({ background: { type: chip.dataset.bgType } }); Theme.apply(); render(); }));

    $('#bg-gradient-from').addEventListener('input', (e) => { AppSettings.update({ background: { gradientFrom: e.target.value } }); Theme.apply(); updateBgPreview(); });
    $('#bg-gradient-to').addEventListener('input', (e) => { AppSettings.update({ background: { gradientTo: e.target.value } }); Theme.apply(); updateBgPreview(); });

    $('#bg-image-input').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 4 * 1024 * 1024) { UICommon.toast('Elige una imagen menor a 4MB'); return; }
      const reader = new FileReader();
      reader.onload = () => {
        AppSettings.update({ background: { image: reader.result, type: 'image' } });
        Theme.apply(); render();
        UICommon.toast('Fondo actualizado');
      };
      reader.readAsDataURL(file);
    });

    $('#bg-opacity').addEventListener('input', (e) => {
      AppSettings.update({ background: { opacity: Number(e.target.value) / 100 } });
      $('#bg-opacity-value').textContent = e.target.value + '%';
      Theme.apply(); updateBgPreview();
    });
    $('#bg-overlay').addEventListener('input', (e) => {
      AppSettings.update({ background: { overlayOpacity: Number(e.target.value) / 100 } });
      $('#bg-overlay-value').textContent = e.target.value + '%';
      Theme.apply(); updateBgPreview();
    });

    $('#btn-reset-appearance').addEventListener('click', () => {
      UICommon.showConfirm('Restablecer apariencia', 'El tema y el fondo volverán a los valores predeterminados.', () => {
        const d = Models.defaultSettings();
        AppSettings.update({ theme: d.theme, background: d.background });
        Theme.apply(); render();
        UICommon.toast('Apariencia restablecida');
      });
    });

    $('#btn-manage-add-player').addEventListener('click', () => {
      const name = prompt('Nombre del nuevo jugador:');
      if (name && name.trim()) {
        Players.getOrCreate(name.trim());
        renderPlayersList();
        UICommon.toast('Jugador agregado');
      }
    });
  }

  return { render, bind };
})();
