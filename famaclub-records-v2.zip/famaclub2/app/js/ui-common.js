/**
 * FamaClub Records — UI común
 * Helpers de DOM compartidos entre todas las pantallas.
 */

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const NAV_HIDDEN_SCREENS = new Set([
  'screen-new-game', 'screen-game-history', 'screen-saved-detail', 'screen-victory', 'screen-table-mode',
]);
const TAB_SCREENS = ['screen-home', 'screen-board', 'screen-beer', 'screen-stats', 'screen-saved-games', 'screen-settings'];

const UICommon = (() => {
  let confirmCallback = null;

  function showScreen(id) {
    $$('.screen').forEach((s) => s.classList.remove('active'));
    const target = document.getElementById(id);
    if (target) target.classList.add('active');

    const nav = $('#bottom-nav');
    if (NAV_HIDDEN_SCREENS.has(id)) {
      nav.style.display = 'none';
      document.body.classList.add('no-nav');
    } else {
      nav.style.display = 'flex';
      document.body.classList.remove('no-nav');
      if (TAB_SCREENS.includes(id)) {
        $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.nav === id));
      }
    }
    window.scrollTo(0, 0);
  }

  function openModal(id) { document.getElementById(id).classList.add('open'); }
  function closeModal(id) { document.getElementById(id).classList.remove('open'); }
  function closeAllModals() { $$('.modal-backdrop').forEach((m) => m.classList.remove('open')); }

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => t.classList.remove('show'), 1500);
  }

  function showConfirm(title, body, onAccept) {
    $('#confirm-title').textContent = title;
    $('#confirm-body').textContent = body;
    confirmCallback = onAccept;
    openModal('modal-confirm');
  }

  function bindConfirmModal() {
    $('#confirm-cancel').addEventListener('click', () => closeModal('modal-confirm'));
    $('#confirm-accept').addEventListener('click', () => {
      closeModal('modal-confirm');
      if (confirmCallback) confirmCallback();
      confirmCallback = null;
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
  }

  function showActionSheet(title, actions) {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop open';
    const sheet = document.createElement('div');
    sheet.className = 'modal-sheet';
    sheet.innerHTML = `<p class="modal-title">${escapeHtml(title)}</p>`;
    const stack = document.createElement('div');
    stack.className = 'btn-stack';
    actions.forEach((a) => {
      const btn = document.createElement('button');
      btn.className = `btn ${a.danger ? 'btn-danger' : 'btn-secondary'}`;
      btn.textContent = a.label;
      btn.addEventListener('click', () => { document.body.removeChild(backdrop); a.action(); });
      stack.appendChild(btn);
    });
    const cancel = document.createElement('button');
    cancel.className = 'btn btn-ghost';
    cancel.textContent = 'Cancelar';
    cancel.addEventListener('click', () => document.body.removeChild(backdrop));
    stack.appendChild(cancel);
    sheet.appendChild(stack);
    backdrop.appendChild(sheet);
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) document.body.removeChild(backdrop); });
    document.body.appendChild(backdrop);
  }

  function formatDate(ts) {
    return new Date(ts).toLocaleString('es', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  function formatTime(ts) {
    return new Date(ts).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' });
  }

  /**
   * Tabla de rondas estilo "hoja de anotación" (columnas por equipo, filas
   * por ronda, verde/rojo según quién ganó esa mano, totales fijos arriba)
   * — la misma idea que usan Kapicú / El Moises Anote, pero editable y con
   * nuestra propia identidad visual. `onCellTap(entries, team)` es opcional;
   * si se omite, la tabla queda de solo lectura (para partidas guardadas).
   */
  function renderRoundsGrid(container, game, onCellTap) {
    const t1 = game.team1, t2 = game.team2;
    const rounds = {};
    let maxRound = 0;
    game.entries.forEach((e) => {
      rounds[e.round] = rounds[e.round] || { t1: [], t2: [] };
      rounds[e.round][e.teamId === t1.id ? 't1' : 't2'].push(e);
      if (e.round > maxRound) maxRound = e.round;
    });

    const total1 = Models.scoreFor(game, t1.id);
    const total2 = Models.scoreFor(game, t2.id);

    let html = `
      <div class="rounds-grid">
        <div class="rg-header">
          <div class="rg-col-label"></div>
          <div class="rg-col-name">${escapeHtml(t1.name)}</div>
          <div class="rg-col-name">${escapeHtml(t2.name)}</div>
        </div>
        <div class="rg-row rg-total">
          <div class="rg-col-label">TOTAL</div>
          <div class="rg-cell">${total1}</div>
          <div class="rg-cell">${total2}</div>
        </div>
        <div class="rg-body">`;

    for (let r = maxRound; r >= 1; r--) {
      const cell = rounds[r] || { t1: [], t2: [] };
      const sum1 = cell.t1.reduce((s, e) => s + e.points, 0);
      const sum2 = cell.t2.reduce((s, e) => s + e.points, 0);
      const has1 = cell.t1.length > 0, has2 = cell.t2.length > 0;
      let cls1 = '', cls2 = '';
      if (has1 || has2) {
        if (sum1 > sum2) { cls1 = 'rg-win'; cls2 = 'rg-lose'; }
        else if (sum2 > sum1) { cls2 = 'rg-win'; cls1 = 'rg-lose'; }
      }
      html += `
        <div class="rg-row" data-round="${r}">
          <div class="rg-col-label">P${r}</div>
          <div class="rg-cell ${cls1} ${has1 ? 'rg-tappable' : ''}" data-round="${r}" data-team="t1">${has1 ? sum1 : '–'}</div>
          <div class="rg-cell ${cls2} ${has2 ? 'rg-tappable' : ''}" data-round="${r}" data-team="t2">${has2 ? sum2 : '–'}</div>
        </div>`;
    }
    html += `</div></div>`;
    if (maxRound === 0) html = '<div class="empty-state">Todavía no hay anotaciones.</div>';
    container.innerHTML = html;

    if (onCellTap) {
      Array.from(container.querySelectorAll('.rg-cell.rg-tappable')).forEach((cellEl) => {
        cellEl.addEventListener('click', () => {
          const round = Number(cellEl.dataset.round);
          const teamKey = cellEl.dataset.team;
          const teamId = teamKey === 't1' ? t1.id : t2.id;
          const entries = (rounds[round] || {})[teamKey] || [];
          onCellTap(entries, teamId, round);
        });
      });
    }
  }

  function bindBottomNav() {
    $$('.nav-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        Feedback.tap();
        showScreen(btn.dataset.nav);
        document.dispatchEvent(new CustomEvent('nav-changed', { detail: btn.dataset.nav }));
      });
    });
    $$('[data-back]').forEach((btn) => btn.addEventListener('click', () => showScreen(btn.dataset.back)));
    $$('[data-nav]:not(.nav-btn)').forEach((btn) => {
      btn.addEventListener('click', () => {
        showScreen(btn.dataset.nav);
        document.dispatchEvent(new CustomEvent('nav-changed', { detail: btn.dataset.nav }));
      });
    });
  }

  function init() {
    bindConfirmModal();
    bindBottomNav();
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeAllModals(); });
  }

  return {
    showScreen, openModal, closeModal, closeAllModals, toast, showConfirm,
    escapeHtml, showActionSheet, formatDate, formatTime, renderRoundsGrid, init,
  };
})();
