/**
 * FamaClub Records — Cervezas
 * Tres sub-pestañas: Personal (consumo), Deudas (pendientes + liquidar),
 * Historial (todo el movimiento con fecha y hora).
 */

const UIBeer = (() => {
  let activeBeerPlayerId = null;
  let activeDebtId = null;
  let beerQty = 1;

  function findGame(gameId) {
    if (!gameId) return null;
    const active = StateGame.getGame();
    if (active && active.id === gameId) return active;
    return StateGame.history().find((g) => g.id === gameId) || null;
  }

  function partyName(type, id, gameId) {
    if (type === 'player') return UIBoard.playerName(id);
    const game = findGame(gameId);
    if (!game) return 'Equipo';
    if (game.team1.id === id) return game.team1.name;
    if (game.team2.id === id) return game.team2.name;
    return 'Equipo';
  }

  function switchTab(name) {
    $$('.beer-tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.beertab === name));
    $$('.beer-tab-panel').forEach((p) => p.classList.remove('active'));
    $(`#beer-panel-${name}`).classList.add('active');
  }

  function render() {
    renderPersonal();
    renderDebts();
    renderHistory();
  }

  function renderPersonal() {
    const players = Players.all();
    const list = $('#beer-players-list');
    list.innerHTML = '';
    $('#beer-no-players').style.display = players.length === 0 ? 'block' : 'none';
    players.forEach((p) => {
      const stats = Stats.playerStats(p.id);
      const card = document.createElement('div');
      card.className = 'beer-player-card';
      card.innerHTML = `
        <div>
          <div class="beer-player-name">${UICommon.escapeHtml(p.name)}</div>
          <div class="beer-player-count">🍺 ${stats.consumidas} consumidas · ${stats.ganadas} ganadas · ${stats.debidas} debidas</div>
        </div>
        <button class="beer-add-btn" data-player="${p.id}">+</button>
      `;
      list.appendChild(card);
    });
    Array.from(list.querySelectorAll('.beer-add-btn')).forEach((btn) => {
      btn.addEventListener('click', () => openAddBeer(btn.dataset.player));
    });
  }

  function renderDebts() {
    const debts = StateBeer.pendingDebts();
    const list = $('#beer-debts-list');
    list.innerHTML = '';
    $('#beer-no-debts').style.display = debts.length === 0 ? 'block' : 'none';
    debts.forEach((d) => {
      const debtorName = partyName(d.debtorType, d.debtorId, d.gameId);
      const creditorName = partyName(d.creditorType, d.creditorId, d.gameId);
      const card = document.createElement('div');
      card.className = 'debt-card';
      card.innerHTML = `
        <div class="debt-text"><b>${UICommon.escapeHtml(debtorName)}</b> debe <b>${d.remaining} 🍺</b> a <b>${UICommon.escapeHtml(creditorName)}</b>${d.status === 'partial' ? ' <span style="color:var(--ink-dim);font-weight:600;">(pago parcial)</span>' : ''}</div>
        <div class="debt-actions">
          <button class="btn btn-primary btn-sm liquidar-btn" data-debt="${d.id}">Liquidar</button>
        </div>
      `;
      list.appendChild(card);
    });
    Array.from(list.querySelectorAll('.liquidar-btn')).forEach((btn) => {
      btn.addEventListener('click', () => openPayDebt(btn.dataset.debt));
    });
  }

  function renderHistory() {
    const consumption = StateBeer.allEntries().map((e) => ({ kind: 'consumo', ts: e.timestamp, playerId: e.playerId, qty: e.quantity }));
    const paymentsList = StateBeer.allPayments().map((p) => ({ kind: 'pago', ts: p.timestamp, debtorId: p.debtorId, creditorId: p.creditorId, qty: p.quantity, debtId: p.debtId }));
    const combined = [...consumption, ...paymentsList].sort((a, b) => b.ts - a.ts);

    const list = $('#beer-history-list');
    list.innerHTML = '';
    $('#beer-no-history').style.display = combined.length === 0 ? 'block' : 'none';

    combined.forEach((item) => {
      const row = document.createElement('div');
      row.className = 'beer-history-row';
      if (item.kind === 'consumo') {
        row.innerHTML = `
          <div class="beer-history-left"><span class="beer-history-name">🍺 ${UICommon.escapeHtml(UIBoard.playerName(item.playerId))}</span><span class="beer-history-time">${UICommon.formatDate(item.ts)}</span></div>
          <span class="beer-history-qty">+${item.qty}</span>`;
      } else {
        const debt = StateBeer.debtById(item.debtId);
        const debtorName = debt ? partyName(debt.debtorType, item.debtorId, debt.gameId) : 'Alguien';
        const creditorName = debt ? partyName(debt.creditorType, item.creditorId, debt.gameId) : 'alguien';
        row.innerHTML = `
          <div class="beer-history-left"><span class="beer-history-name">💸 ${UICommon.escapeHtml(debtorName)} → ${UICommon.escapeHtml(creditorName)}</span><span class="beer-history-time">${UICommon.formatDate(item.ts)}</span></div>
          <span class="beer-history-qty">${item.qty} 🍺</span>`;
      }
      list.appendChild(row);
    });
  }

  // ---------------- Modal: agregar cerveza ----------------

  function openAddBeer(playerId) {
    activeBeerPlayerId = playerId;
    beerQty = 1;
    $('#add-beer-title').textContent = `${UIBoard.playerName(playerId)} — agregar cerveza`;
    $$('#beer-qty-row .chip').forEach((c) => c.classList.toggle('selected', c.dataset.beerqty === '1'));
    $('#input-beer-custom').style.display = 'none';
    UICommon.openModal('modal-add-beer');
  }

  function bindAddBeerModal() {
    $$('#beer-qty-row .chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        $$('#beer-qty-row .chip').forEach((c) => c.classList.remove('selected'));
        chip.classList.add('selected');
        Feedback.tap();
        if (chip.dataset.beerqty === 'custom') {
          $('#input-beer-custom').style.display = 'block';
          $('#input-beer-custom').focus();
          beerQty = 0;
        } else {
          $('#input-beer-custom').style.display = 'none';
          beerQty = Number(chip.dataset.beerqty);
        }
      });
    });
    $('#input-beer-custom').addEventListener('input', (e) => { beerQty = Number(e.target.value) || 0; });

    $('#btn-confirm-beer').addEventListener('click', () => {
      if (!activeBeerPlayerId || beerQty <= 0) { UICommon.toast('Elige una cantidad válida'); return; }
      const activeGame = StateGame.getGame();
      StateBeer.addEntry(activeBeerPlayerId, beerQty, activeGame ? activeGame.id : null, '');
      Feedback.beerAdded();
      UICommon.closeModal('modal-add-beer');
      renderPersonal();
      renderHistory();
      UICommon.toast('Cerveza registrada 🍺');
    });
  }

  // ---------------- Modal: liquidar deuda ----------------

  function openPayDebt(debtId) {
    activeDebtId = debtId;
    const debt = StateBeer.debtById(debtId);
    if (!debt) return;
    $('#pay-debt-title').textContent = `Liquidar ${debt.remaining} 🍺 pendientes`;
    $('#input-pay-quantity').value = debt.remaining;
    $('#input-pay-quantity').max = debt.remaining;
    UICommon.openModal('modal-pay-debt');
  }

  function bindPayDebtModal() {
    $('#btn-pay-full').addEventListener('click', () => {
      const debt = StateBeer.debtById(activeDebtId);
      if (!debt) return;
      StateBeer.payDebt(activeDebtId, debt.remaining);
      UICommon.closeModal('modal-pay-debt');
      renderDebts();
      renderHistory();
      UICommon.toast('Deuda liquidada');
    });
    $('#btn-pay-partial').addEventListener('click', () => {
      const qty = Number($('#input-pay-quantity').value);
      if (!qty || qty <= 0) { UICommon.toast('Ingresa una cantidad válida'); return; }
      const ok = StateBeer.payDebt(activeDebtId, qty);
      if (ok) {
        UICommon.closeModal('modal-pay-debt');
        renderDebts();
        renderHistory();
        UICommon.toast('Pago registrado');
      }
    });
  }

  function bind() {
    $$('.beer-tab-btn').forEach((btn) => btn.addEventListener('click', () => { switchTab(btn.dataset.beertab); Feedback.tap(); }));
    bindAddBeerModal();
    bindPayDebtModal();
  }

  return { render, bind, partyName };
})();
