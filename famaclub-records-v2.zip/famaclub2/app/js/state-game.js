/**
 * FamaClub Records — Estado de partida (v2)
 * No toca el DOM. El puntaje SIEMPRE se deriva de `entries`, nunca se
 * guarda como número suelto: así el marcador jamás puede desincronizarse
 * de su propio historial (sección 10 y 42 del brief).
 */

const StateGame = (() => {
  let game = null;
  let undoStack = [];
  let redoStack = [];
  let listeners = [];

  function onChange(fn) { listeners.push(fn); }
  function emit(evt) { listeners.forEach((fn) => fn(evt)); }

  function init() {
    game = Storage.loadActiveGame();
  }

  function getGame() { return game; }
  function hasActiveGame() { return !!game && game.status === 'active'; }

  function persist() {
    if (game) Storage.saveActiveGame(game);
  }

  function pushUndo() {
    undoStack.push(JSON.stringify(game.entries));
    redoStack = [];
    if (undoStack.length > 200) undoStack.shift();
  }

  // ---------------- Ciclo de vida ----------------

  function newGame({ team1Name, team2Name, player1Id, player2Id, player3Id, player4Id, targetScore, beerEnabled, beerRule }) {
    const team1 = Models.createTeam(team1Name, [player1Id, player2Id]);
    const team2 = Models.createTeam(team2Name, [player3Id, player4Id]);
    game = Models.createGame({ team1, team2, targetScore, beerEnabled, beerRule });
    undoStack = [];
    redoStack = [];
    persist();
    emit('new-game');
    return game;
  }

  function updateTeamName(teamId, name) {
    if (!game) return false;
    const clean = (name || '').trim();
    if (!clean) return false;
    if (game.team1.id === teamId) game.team1.name = clean;
    else if (game.team2.id === teamId) game.team2.name = clean;
    else return false;
    persist();
    emit('team-renamed');
    return true;
  }

  function abandonActiveGame() {
    if (game) {
      game.status = 'abandoned';
      game.finishedAt = Date.now();
      Storage.addFinishedGame(game);
    }
    Storage.clearActiveGame();
    game = null;
    undoStack = [];
    redoStack = [];
    emit('game-cleared');
  }

  function discardActiveGameSilently() {
    // Para "reiniciar": no se guarda en historial, simplemente se descarta.
    Storage.clearActiveGame();
    game = null;
    undoStack = [];
    redoStack = [];
  }

  function restartGame() {
    if (!game) return;
    const { team1, team2, targetScore, beerEnabled, beerRule } = game;
    game = Models.createGame({
      team1: Models.createTeam(team1.name, team1.playerIds),
      team2: Models.createTeam(team2.name, team2.playerIds),
      targetScore,
      beerEnabled,
      beerRule,
    });
    undoStack = [];
    redoStack = [];
    persist();
    emit('game-restarted');
  }

  // ---------------- Puntuación ----------------

  function shouldBumpRound() {
    if (game.entries.length === 0) return false;
    const round = Models.currentRound(game);
    const teamsInRound = new Set(game.entries.filter((e) => e.round === round).map((e) => e.teamId));
    return teamsInRound.has(game.team1.id) && teamsInRound.has(game.team2.id);
  }

  function addPoints(teamId, points) {
    if (!game || game.status !== 'active') return false;
    const n = Number(points);
    if (!Number.isFinite(n) || n === 0) return false;
    pushUndo();
    const round = Models.currentRound(game) + (shouldBumpRound() ? 1 : 0);
    game.entries.push(Models.createEntry(teamId, n, round));
    afterMutation();
    return true;
  }

  function editEntry(entryId, newPoints) {
    if (!game) return false;
    const n = Number(newPoints);
    if (!Number.isFinite(n)) return false;
    const entry = game.entries.find((e) => e.id === entryId);
    if (!entry) return false;
    pushUndo();
    entry.points = n;
    afterMutation();
    return true;
  }

  function deleteEntry(entryId) {
    if (!game) return false;
    const idx = game.entries.findIndex((e) => e.id === entryId);
    if (idx === -1) return false;
    pushUndo();
    game.entries.splice(idx, 1);
    afterMutation();
    return true;
  }

  function canUndo() { return undoStack.length > 0; }
  function canRedo() { return redoStack.length > 0; }

  function undo() {
    if (!canUndo()) return false;
    redoStack.push(JSON.stringify(game.entries));
    game.entries = JSON.parse(undoStack.pop());
    syncWinnerState();
    persist();
    emit('score-changed');
    return true;
  }

  function redo() {
    if (!canRedo()) return false;
    undoStack.push(JSON.stringify(game.entries));
    game.entries = JSON.parse(redoStack.pop());
    syncWinnerState();
    persist();
    emit('score-changed');
    return true;
  }

  function syncWinnerState() {
    const winnerId = Models.checkWinner(game);
    if (winnerId) {
      game.status = 'finished';
      game.winnerTeamId = winnerId;
      if (!game.finishedAt) game.finishedAt = Date.now();
    } else {
      game.status = 'active';
      game.winnerTeamId = null;
      game.finishedAt = null;
    }
  }

  function afterMutation() {
    syncWinnerState();
    persist();
    emit('score-changed');
  }

  // Se llama una sola vez, justo cuando se detecta la victoria, para
  // generar la deuda de cerveza correspondiente (si aplica). Ver ui.js.
  function attachBeerResult(beerResult) {
    if (!game) return;
    game.beerResult = beerResult;
    persist();
  }

  function finalizeAndArchive() {
    if (!game || game.status !== 'finished') return null;
    Storage.addFinishedGame(game);
    Storage.clearActiveGame();
    const finished = game;
    game = null;
    undoStack = [];
    redoStack = [];
    emit('game-archived');
    return finished;
  }

  function scores() {
    if (!game) return null;
    return { team1: Models.scoreFor(game, game.team1.id), team2: Models.scoreFor(game, game.team2.id) };
  }

  function history() { return Storage.loadHistory(); }
  function deleteHistoryGames(ids) { Storage.deleteGames(ids); emit('history-changed'); }
  function clearAllHistory() { Storage.clearHistory(); emit('history-changed'); }

  return {
    init, onChange, getGame, hasActiveGame,
    newGame, updateTeamName, abandonActiveGame, discardActiveGameSilently, restartGame,
    addPoints, editEntry, deleteEntry, canUndo, canRedo, undo, redo,
    attachBeerResult, finalizeAndArchive, scores,
    history, deleteHistoryGames, clearAllHistory,
  };
})();
