/**
 * FamaClub Records — Inicio
 */

const UIHome = (() => {
  function render() {
    $('#btn-continuar-partida').style.display = StateGame.hasActiveGame() ? 'flex' : 'none';
  }

  function bind() {
    $('#btn-nueva-partida').addEventListener('click', () => {
      UINewGame.render();
      UICommon.showScreen('screen-new-game');
    });
    $('#btn-continuar-partida').addEventListener('click', () => {
      UICommon.showScreen('screen-board');
      UIBoard.render();
    });
  }

  return { render, bind };
})();
