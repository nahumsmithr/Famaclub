/**
 * FamaClub Records — Frases divertidas
 * Puramente decorativo, nunca ofensivo, siempre desactivable.
 */

const Phrases = (() => {
  const WIN_PHRASES = [
    (t) => `🔥 ¡${t} está(n) intratable(s)!`,
    (t) => `🏆 ¡Victoria para ${t}!`,
    (t) => `⚡ ${t} no dio tregua esta partida.`,
    (t) => `🎉 ${t} se lleva la mesa.`,
  ];

  const BEER_PHRASES = [
    (t, q) => `🍺 La mesa acaba de generar una deuda de ${q}.`,
    (t, q) => `😂 ${t} tiene(n) ${q} pendiente(s).`,
  ];

  const STREAK_PHRASES = [
    (name, n) => `🔥 ${name} lleva ${n} victorias seguidas.`,
  ];

  function pick(list, ...args) {
    const fn = list[Math.floor(Math.random() * list.length)];
    return fn(...args);
  }

  function forWin(winnerTeamName) {
    if (!AppSettings.get().funnyPhrases) return null;
    return pick(WIN_PHRASES, winnerTeamName);
  }

  function forBeer(loserName, quantity) {
    if (!AppSettings.get().funnyPhrases) return null;
    return pick(BEER_PHRASES, loserName, `${quantity} 🍺`);
  }

  function forStreak(playerName, streak) {
    if (!AppSettings.get().funnyPhrases || streak < 3) return null;
    return pick(STREAK_PHRASES, playerName, streak);
  }

  return { forWin, forBeer, forStreak };
})();
