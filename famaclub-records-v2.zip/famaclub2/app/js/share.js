/**
 * FamaClub Records — Compartir resultado
 * Dibuja una tarjeta con Canvas 2D nativo (sin librerías externas) y
 * usa la Web Share API cuando está disponible; si no, ofrece copiar
 * el resumen como texto.
 */

const Share = (() => {
  function drawCard(game, playerNameOf) {
    const canvas = document.createElement('canvas');
    const W = 900, H = 1000;
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext('2d');

    // Fondo
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, '#0f1720');
    grad.addColorStop(1, '#1c2a3a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Marca
    ctx.fillStyle = '#c49a5b';
    ctx.font = '700 30px -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('FamaClub Records', W / 2, 90);
    ctx.fillStyle = '#aab4bf';
    ctx.font = '600 16px -apple-system, sans-serif';
    ctx.fillText('LA MESA · EL MARCADOR · LA HISTORIA', W / 2, 122);

    ctx.font = '800 40px -apple-system, sans-serif';
    ctx.fillStyle = '#f5f2ea';
    ctx.fillText('🏆 RESULTADO', W / 2, 200);

    const s1 = Models.scoreFor(game, game.team1.id);
    const s2 = Models.scoreFor(game, game.team2.id);
    const winnerIsTeam1 = game.winnerTeamId === game.team1.id;

    function drawTeam(team, score, y, isWinner) {
      ctx.fillStyle = isWinner ? '#4f8f6b' : '#aab4bf';
      ctx.font = '700 22px -apple-system, sans-serif';
      const names = team.playerIds.map(playerNameOf).filter(Boolean).join(' & ') || team.name;
      ctx.fillText(names.toUpperCase(), W / 2, y);
      ctx.fillStyle = '#f5f2ea';
      ctx.font = '800 90px -apple-system, sans-serif';
      ctx.fillText(String(score), W / 2, y + 100);
    }

    drawTeam(game.team1, s1, 300, winnerIsTeam1);
    drawTeam(game.team2, s2, 520, !winnerIsTeam1);

    if (game.beerEnabled && game.beerResult && game.beerResult.totalQuantity > 0) {
      ctx.fillStyle = '#c49a5b';
      ctx.font = '700 28px -apple-system, sans-serif';
      ctx.fillText(`🍺 ${game.beerResult.totalQuantity} cerveza(s) en juego`, W / 2, 650);
    }

    const date = new Date(game.finishedAt || Date.now()).toLocaleString('es', {
      day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
    });
    ctx.fillStyle = '#aab4bf';
    ctx.font = '600 18px -apple-system, sans-serif';
    ctx.fillText(date, W / 2, 940);

    return canvas;
  }

  function summaryText(game, playerNameOf) {
    const s1 = Models.scoreFor(game, game.team1.id);
    const s2 = Models.scoreFor(game, game.team2.id);
    const n1 = game.team1.playerIds.map(playerNameOf).filter(Boolean).join(' y ') || game.team1.name;
    const n2 = game.team2.playerIds.map(playerNameOf).filter(Boolean).join(' y ') || game.team2.name;
    let text = `🏆 FamaClub Records\n${n1}: ${s1}\n${n2}: ${s2}`;
    if (game.beerEnabled && game.beerResult && game.beerResult.totalQuantity > 0) {
      text += `\n🍺 ${game.beerResult.totalQuantity} cerveza(s) en juego`;
    }
    return text;
  }

  async function shareGame(game, playerNameOf) {
    const canvas = drawCard(game, playerNameOf);
    const text = summaryText(game, playerNameOf);

    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
    const file = blob ? new File([blob], 'famaclub-resultado.png', { type: 'image/png' }) : null;

    if (navigator.share && file && navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: 'FamaClub Records', text });
        return { ok: true, method: 'share-file' };
      } catch (e) {
        if (e && e.name === 'AbortError') return { ok: false, method: 'cancelled' };
      }
    }

    if (navigator.share) {
      try {
        await navigator.share({ title: 'FamaClub Records', text });
        return { ok: true, method: 'share-text' };
      } catch (e) {
        if (e && e.name === 'AbortError') return { ok: false, method: 'cancelled' };
      }
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return { ok: true, method: 'clipboard' };
    }

    return { ok: false, method: 'unsupported' };
  }

  return { shareGame, drawCard, summaryText };
})();
