/**
 * FamaClub Records — Configuración de la app
 * Único lugar donde vive Settings. Todo lo demás lo lee de aquí.
 */

const AppSettings = (() => {
  let settings = Models.defaultSettings();
  let listeners = [];

  function onChange(fn) { listeners.push(fn); }
  function emit() { listeners.forEach((fn) => fn()); }

  function init() {
    const saved = Storage.loadSettings();
    if (saved) {
      const d = Models.defaultSettings();
      settings = {
        ...d,
        ...saved,
        beerRuleDefault: { ...d.beerRuleDefault, ...(saved.beerRuleDefault || {}) },
        background: { ...d.background, ...(saved.background || {}) },
      };
    }
  }

  function get() { return settings; }

  function update(patch) {
    settings = {
      ...settings,
      ...patch,
      beerRuleDefault: { ...settings.beerRuleDefault, ...(patch.beerRuleDefault || {}) },
      background: { ...settings.background, ...(patch.background || {}) },
    };
    Storage.saveSettings(settings);
    emit();
  }

  return { init, onChange, get, update };
})();
