/**
 * FamaClub Records — Estado de cervezas (v2)
 * Ledger independiente del marcador de puntos (sección 42 del brief).
 * El único punto de contacto con una partida es generateDebtsForGame(),
 * llamado una sola vez cuando una partida con cervezas activas termina.
 */

const StateBeer = (() => {
  let entries = []; // BeerEntry[] — consumo personal
  let debts = [];   // BeerDebt[]
  let payments = []; // BeerPayment[]
  let listeners = [];

  function onChange(fn) { listeners.push(fn); }
  function emit(evt) { listeners.forEach((fn) => fn(evt)); }

  function init() {
    entries = Storage.loadBeerEntries();
    debts = Storage.loadBeerDebts();
    payments = Storage.loadBeerPayments();
  }

  function persistEntries() { Storage.saveBeerEntries(entries); }
  function persistDebts() { Storage.saveBeerDebts(debts); }
  function persistPayments() { Storage.saveBeerPayments(payments); }

  // ---------------- Consumo personal ----------------

  function addEntry(playerId, quantity, gameId, note) {
    const n = Number(quantity);
    if (!playerId || !Number.isFinite(n) || n <= 0) return null;
    const entry = Models.createBeerEntry(playerId, n, gameId, note);
    entries.push(entry);
    persistEntries();
    emit('beer-entry-added');
    return entry;
  }

  function editEntry(id, quantity) {
    const n = Number(quantity);
    const entry = entries.find((e) => e.id === id);
    if (!entry || !Number.isFinite(n) || n <= 0) return false;
    entry.quantity = n;
    persistEntries();
    emit('beer-entry-changed');
    return true;
  }

  function deleteEntry(id) {
    const idx = entries.findIndex((e) => e.id === id);
    if (idx === -1) return false;
    entries.splice(idx, 1);
    persistEntries();
    emit('beer-entry-changed');
    return true;
  }

  function allEntries() { return entries.slice().sort((a, b) => b.timestamp - a.timestamp); }
  function entriesForPlayer(playerId) { return entries.filter((e) => e.playerId === playerId); }
  function totalConsumed(playerId) { return entriesForPlayer(playerId).reduce((s, e) => s + e.quantity, 0); }

  // ---------------- Generación de deudas al finalizar una partida ----------------

  /**
   * Genera las deudas según la regla configurada en el Game.
   * `customAssignments` (opcional) permite sobreescribir la distribución
   * automática cuando beerRule.distribution === 'personalizado'.
   * Devuelve un `beerResult` resumido para guardar en game.beerResult.
   */
  function generateDebtsForGame(game, customAssignments) {
    if (!game.beerEnabled || !game.winnerTeamId) return null;
    const winner = game.winnerTeamId === game.team1.id ? game.team1 : game.team2;
    const loser = Models.otherTeam(game, winner.id);
    const rule = game.beerRule;
    const created = [];

    function addDebt(spec) {
      const debt = Models.createBeerDebt({ ...spec, gameId: game.id });
      debts.push(debt);
      created.push(debt);
    }

    if (rule.distribution === 'personalizado' && Array.isArray(customAssignments) && customAssignments.length) {
      customAssignments.forEach((a) => {
        if (Number(a.quantity) > 0) {
          addDebt({
            debtorType: 'player',
            debtorId: a.debtorId,
            creditorType: 'team',
            creditorId: winner.id,
            quantity: a.quantity,
          });
        }
      });
    } else if (rule.distribution === 'jugador') {
      loser.playerIds.forEach((playerId) => {
        addDebt({
          debtorType: 'player',
          debtorId: playerId,
          creditorType: 'team',
          creditorId: winner.id,
          quantity: rule.amountPerLoss,
        });
      });
    } else {
      // 'equipo': una sola deuda de equipo a equipo
      addDebt({
        debtorType: 'team',
        debtorId: loser.id,
        creditorType: 'team',
        creditorId: winner.id,
        quantity: rule.amountPerLoss,
      });
    }

    persistDebts();
    emit('beer-debts-changed');

    const totalQuantity = created.reduce((s, d) => s + d.quantity, 0);
    return {
      distribution: rule.distribution,
      amountPerLoss: rule.amountPerLoss,
      totalQuantity,
      winnerTeamId: winner.id,
      loserTeamId: loser.id,
      debtIds: created.map((d) => d.id),
    };
  }

  // ---------------- Consulta de deudas ----------------

  function allDebts() { return debts.slice().sort((a, b) => b.createdAt - a.createdAt); }
  function pendingDebts() { return allDebts().filter((d) => d.remaining > 0); }
  function debtsForGame(gameId) { return debts.filter((d) => d.gameId === gameId); }

  function debtById(id) { return debts.find((d) => d.id === id); }

  // ---------------- Pagos / liquidación ----------------

  function payDebt(debtId, quantity) {
    const debt = debtById(debtId);
    if (!debt) return false;
    const amount = Math.min(Number(quantity) || 0, debt.remaining);
    if (amount <= 0) return false;
    debt.remaining -= amount;
    debt.status = debt.remaining <= 0 ? 'paid' : 'partial';
    const payment = Models.createBeerPayment({
      debtId: debt.id,
      debtorId: debt.debtorId,
      creditorId: debt.creditorId,
      quantity: amount,
      gameId: debt.gameId,
    });
    payments.push(payment);
    persistDebts();
    persistPayments();
    emit('beer-debts-changed');
    return true;
  }

  function allPayments() { return payments.slice().sort((a, b) => b.timestamp - a.timestamp); }

  return {
    init, onChange,
    addEntry, editEntry, deleteEntry, allEntries, entriesForPlayer, totalConsumed,
    generateDebtsForGame, allDebts, pendingDebts, debtsForGame, debtById, payDebt, allPayments,
  };
})();
