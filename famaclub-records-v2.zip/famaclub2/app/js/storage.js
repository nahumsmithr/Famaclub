/**
 * FamaClub Records — Persistencia (v2)
 * 100% local. Cero peticiones de red. Todo el I/O de la app pasa por aquí.
 */

const Storage = (() => {
  const KEYS = {
    PLAYERS: 'fcr_players_v2',
    ACTIVE_GAME: 'fcr_active_game_v2',
    HISTORY: 'fcr_history_v2',
    BEER_ENTRIES: 'fcr_beer_entries_v2',
    BEER_DEBTS: 'fcr_beer_debts_v2',
    BEER_PAYMENTS: 'fcr_beer_payments_v2',
    SETTINGS: 'fcr_settings_v2',
  };

  function safeGet(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.error('Storage read error', key, e);
      return fallback;
    }
  }

  function safeSet(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error('Storage write error', key, e);
      return false;
    }
  }

  return {
    KEYS,

    // Jugadores guardados
    loadPlayers: () => safeGet(KEYS.PLAYERS, []),
    savePlayers: (list) => safeSet(KEYS.PLAYERS, list),

    // Partida activa
    loadActiveGame: () => safeGet(KEYS.ACTIVE_GAME, null),
    saveActiveGame: (game) => safeSet(KEYS.ACTIVE_GAME, game),
    clearActiveGame: () => localStorage.removeItem(KEYS.ACTIVE_GAME),

    // Historial de partidas
    loadHistory: () => safeGet(KEYS.HISTORY, []),
    addFinishedGame: (game) => {
      const list = safeGet(KEYS.HISTORY, []);
      list.unshift(game);
      safeSet(KEYS.HISTORY, list);
    },
    deleteGames: (ids) => {
      const idSet = new Set(ids);
      const list = safeGet(KEYS.HISTORY, []).filter((g) => !idSet.has(g.id));
      safeSet(KEYS.HISTORY, list);
    },
    clearHistory: () => safeSet(KEYS.HISTORY, []),

    // Cervezas — consumo personal
    loadBeerEntries: () => safeGet(KEYS.BEER_ENTRIES, []),
    saveBeerEntries: (list) => safeSet(KEYS.BEER_ENTRIES, list),

    // Cervezas — deudas
    loadBeerDebts: () => safeGet(KEYS.BEER_DEBTS, []),
    saveBeerDebts: (list) => safeSet(KEYS.BEER_DEBTS, list),

    // Cervezas — pagos
    loadBeerPayments: () => safeGet(KEYS.BEER_PAYMENTS, []),
    saveBeerPayments: (list) => safeSet(KEYS.BEER_PAYMENTS, list),

    // Configuración
    loadSettings: () => safeGet(KEYS.SETTINGS, null),
    saveSettings: (s) => safeSet(KEYS.SETTINGS, s),
  };
})();
