/**
 * FamaClub Records — Jugadores guardados
 * Permite crear partidas rápido reutilizando nombres ya usados antes.
 */

const Players = (() => {
  let list = [];
  let listeners = [];

  function onChange(fn) { listeners.push(fn); }
  function emit() { listeners.forEach((fn) => fn()); }

  function init() {
    list = Storage.loadPlayers();
  }

  function all() {
    return list.slice().sort((a, b) => a.name.localeCompare(b.name, 'es'));
  }

  function findByName(name) {
    const clean = name.trim().toLowerCase();
    return list.find((p) => p.name.toLowerCase() === clean);
  }

  function getOrCreate(name) {
    const clean = (name || '').trim();
    if (!clean) return null;
    const existing = findByName(clean);
    if (existing) return existing;
    const player = Models.createPlayer(clean);
    list.push(player);
    Storage.savePlayers(list);
    emit();
    return player;
  }

  function byId(id) {
    return list.find((p) => p.id === id);
  }

  function rename(id, newName) {
    const clean = (newName || '').trim();
    if (!clean) return false;
    const player = byId(id);
    if (!player) return false;
    player.name = clean;
    Storage.savePlayers(list);
    emit();
    return true;
  }

  function remove(id) {
    list = list.filter((p) => p.id !== id);
    Storage.savePlayers(list);
    emit();
  }

  return { init, onChange, all, findByName, getOrCreate, byId, rename, remove };
})();
