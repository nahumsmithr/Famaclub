/**
 * FamaClub Records — Estadísticas
 * Todo se calcula al vuelo a partir del historial de partidas y del
 * ledger de cervezas. Nunca se persiste un número de estadística:
 * así nunca puede desincronizarse de los datos reales (misma filosofía
 * que el marcador de puntos).
 */

const Stats = (() => {
  function finishedGames() {
    return StateGame.history().filter((g) => g.status === 'finished');
  }

  function findGameById(id) {
    const active = StateGame.getGame();
    if (active && active.id === id) return active;
    return StateGame.history().find((g) => g.id === id) || null;
  }

  function teamPlayerIds(gameId, teamId) {
    const game = findGameById(gameId);
    if (!game) return [];
    if (game.team1.id === teamId) return game.team1.playerIds;
    if (game.team2.id === teamId) return game.team2.playerIds;
    return [];
  }

  // ---------------- Estadísticas por jugador ----------------

  function playerStats(playerId) {
    const games = finishedGames().filter(
      (g) => g.team1.playerIds.includes(playerId) || g.team2.playerIds.includes(playerId)
    );
    let victorias = 0;
    games.forEach((g) => {
      const myTeamId = g.team1.playerIds.includes(playerId) ? g.team1.id : g.team2.id;
      if (g.winnerTeamId === myTeamId) victorias += 1;
    });
    const partidas = games.length;
    const derrotas = partidas - victorias;
    const porcentaje = partidas > 0 ? (victorias / partidas) * 100 : 0;

    let ganadas = 0;
    let debidas = 0;
    StateBeer.allDebts().forEach((d) => {
      const isCreditor =
        (d.creditorType === 'player' && d.creditorId === playerId) ||
        (d.creditorType === 'team' && teamPlayerIds(d.gameId, d.creditorId).includes(playerId));
      const isDebtor =
        (d.debtorType === 'player' && d.debtorId === playerId) ||
        (d.debtorType === 'team' && teamPlayerIds(d.gameId, d.debtorId).includes(playerId));
      if (isCreditor) ganadas += d.quantity;
      if (isDebtor) debidas += d.remaining;
    });

    const consumidas = StateBeer.totalConsumed(playerId);
    const balance = ganadas - debidas;

    return { playerId, partidas, victorias, derrotas, porcentaje, consumidas, ganadas, debidas, balance };
  }

  // ---------------- Estadísticas por pareja ----------------

  function pairKey(ids) { return ids.slice().sort().join('|'); }

  function allPairStats() {
    const map = new Map();
    finishedGames().forEach((g) => {
      [g.team1, g.team2].forEach((team) => {
        if (team.playerIds.length !== 2 || !team.playerIds[0] || !team.playerIds[1]) return;
        const key = pairKey(team.playerIds);
        if (!map.has(key)) map.set(key, { playerIds: team.playerIds.slice().sort(), partidas: 0, victorias: 0 });
        const stat = map.get(key);
        stat.partidas += 1;
        if (g.winnerTeamId === team.id) stat.victorias += 1;
      });
    });
    return Array.from(map.values()).map((s) => ({
      ...s,
      derrotas: s.partidas - s.victorias,
      porcentaje: s.partidas > 0 ? (s.victorias / s.partidas) * 100 : 0,
    }));
  }

  function pairStats(playerIds) {
    const key = pairKey(playerIds);
    return allPairStats().find((s) => pairKey(s.playerIds) === key) || null;
  }

  // ---------------- Récords de la mesa ----------------

  function records() {
    const games = finishedGames();
    let mayorPuntuacion = null; // { teamName, score, gameId }
    let mayorDiferencia = null; // { teamName, diff, gameId }

    games.forEach((g) => {
      const s1 = Models.scoreFor(g, g.team1.id);
      const s2 = Models.scoreFor(g, g.team2.id);
      [{ team: g.team1, score: s1, other: s2 }, { team: g.team2, score: s2, other: s1 }].forEach((c) => {
        if (!mayorPuntuacion || c.score > mayorPuntuacion.score) {
          mayorPuntuacion = { teamName: c.team.name, score: c.score, gameId: g.id };
        }
        const diff = c.score - c.other;
        if (diff > 0 && (!mayorDiferencia || diff > mayorDiferencia.diff)) {
          mayorDiferencia = { teamName: c.team.name, diff, gameId: g.id };
        }
      });
    });

    // Más victorias / más partidas (requiere conocer nombres de jugadores)
    const playerIdSet = new Set();
    games.forEach((g) => { g.team1.playerIds.forEach((id) => playerIdSet.add(id)); g.team2.playerIds.forEach((id) => playerIdSet.add(id)); });
    let masVictorias = null;
    let masPartidas = null;
    playerIdSet.forEach((id) => {
      const s = playerStats(id);
      if (!masVictorias || s.victorias > masVictorias.victorias) masVictorias = { playerId: id, victorias: s.victorias };
      if (!masPartidas || s.partidas > masPartidas.partidas) masPartidas = { playerId: id, partidas: s.partidas };
    });

    let masCervezas = null;
    StateBeer.allEntries().forEach((e) => {
      const total = StateBeer.totalConsumed(e.playerId);
      if (!masCervezas || total > masCervezas.total) masCervezas = { playerId: e.playerId, total };
    });

    return { mayorPuntuacion, mayorDiferencia, masVictorias, masPartidas, masCervezas };
  }

  return { playerStats, allPairStats, pairStats, records, finishedGames };
})();
