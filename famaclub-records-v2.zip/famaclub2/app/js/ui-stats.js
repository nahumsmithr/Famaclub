/**
 * FamaClub Records — Estadísticas
 */

const UIStats = (() => {
  function switchTab(name) {
    $$('.stats-tabs .beer-tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.statstab === name));
    $$('#screen-stats .beer-tab-panel').forEach((p) => p.classList.remove('active'));
    $(`#stats-panel-${name}`).classList.add('active');
  }

  function render() {
    renderPlayers();
    renderPairs();
    renderRecords();
  }

  function renderPlayers() {
    const players = Players.all();
    const list = $('#stats-players-list');
    list.innerHTML = '';
    $('#stats-no-players').style.display = players.length === 0 ? 'block' : 'none';
    players.forEach((p) => {
      const s = Stats.playerStats(p.id);
      const card = document.createElement('div');
      card.className = 'stat-card';
      card.innerHTML = `
        <div class="stat-card-name">${UICommon.escapeHtml(p.name)}</div>
        <div class="stat-grid">
          <div><div class="stat-item-value">${s.partidas}</div><div class="stat-item-label">Partidas</div></div>
          <div><div class="stat-item-value">${s.victorias}</div><div class="stat-item-label">Victorias</div></div>
          <div><div class="stat-item-value">${s.porcentaje.toFixed(1)}%</div><div class="stat-item-label">Efectividad</div></div>
          <div><div class="stat-item-value">${s.consumidas}</div><div class="stat-item-label">🍺 Consumidas</div></div>
          <div><div class="stat-item-value">${s.ganadas}</div><div class="stat-item-label">🍺 Ganadas</div></div>
          <div><div class="stat-item-value">${s.balance >= 0 ? '+' : ''}${s.balance}</div><div class="stat-item-label">Balance</div></div>
        </div>
      `;
      list.appendChild(card);
    });
  }

  function renderPairs() {
    const pairs = Stats.allPairStats();
    const list = $('#stats-pairs-list');
    list.innerHTML = '';
    $('#stats-no-pairs').style.display = pairs.length === 0 ? 'block' : 'none';
    pairs.sort((a, b) => b.partidas - a.partidas).forEach((pair) => {
      const names = pair.playerIds.map(UIBoard.playerName).join(' + ');
      const card = document.createElement('div');
      card.className = 'stat-card';
      card.innerHTML = `
        <div class="stat-card-name">${UICommon.escapeHtml(names)}</div>
        <div class="stat-grid">
          <div><div class="stat-item-value">${pair.partidas}</div><div class="stat-item-label">Partidas</div></div>
          <div><div class="stat-item-value">${pair.victorias}</div><div class="stat-item-label">Victorias</div></div>
          <div><div class="stat-item-value">${pair.porcentaje.toFixed(1)}%</div><div class="stat-item-label">Efectividad</div></div>
        </div>
      `;
      list.appendChild(card);
    });
  }

  function renderRecords() {
    const r = Stats.records();
    const list = $('#stats-records-list');
    list.innerHTML = '';
    const items = [];
    if (r.mayorPuntuacion) items.push({ icon: '🔥', title: 'Mayor puntuación', value: `${UICommon.escapeHtml(r.mayorPuntuacion.teamName)} — ${r.mayorPuntuacion.score}` });
    if (r.mayorDiferencia) items.push({ icon: '💥', title: 'Mayor diferencia', value: `${UICommon.escapeHtml(r.mayorDiferencia.teamName)} — +${r.mayorDiferencia.diff}` });
    if (r.masVictorias) items.push({ icon: '🏆', title: 'Más victorias', value: `${UICommon.escapeHtml(UIBoard.playerName(r.masVictorias.playerId))} — ${r.masVictorias.victorias}` });
    if (r.masPartidas) items.push({ icon: '🎯', title: 'Más partidas', value: `${UICommon.escapeHtml(UIBoard.playerName(r.masPartidas.playerId))} — ${r.masPartidas.partidas}` });
    if (r.masCervezas) items.push({ icon: '🍺', title: 'Más cervezas consumidas', value: `${UICommon.escapeHtml(UIBoard.playerName(r.masCervezas.playerId))} — ${r.masCervezas.total} 🍺` });

    $('#stats-no-records').style.display = items.length === 0 ? 'block' : 'none';
    items.forEach((it) => {
      const card = document.createElement('div');
      card.className = 'record-card';
      card.innerHTML = `<span class="record-icon">${it.icon}</span><div><div class="record-title">${it.title}</div><div class="record-value">${it.value}</div></div>`;
      list.appendChild(card);
    });
  }

  function bind() {
    $$('.stats-tabs .beer-tab-btn').forEach((btn) => btn.addEventListener('click', () => { switchTab(btn.dataset.statstab); Feedback.tap(); }));
  }

  return { render, bind };
})();
