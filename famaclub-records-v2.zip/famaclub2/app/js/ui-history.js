/**
 * FamaClub Records — Historial de partidas guardadas
 */

const UIHistory = (() => {
  let selectMode = false;
  let selectedIds = new Set();
  let currentDetailGame = null;

  function render() {
    const list = StateGame.history();
    const container = $('#saved-games-list');
    container.innerHTML = '';
    $('#saved-games-empty').style.display = list.length === 0 ? 'block' : 'none';
    selectedIds.clear();
    updateBulkVisibility();

    list.forEach((game) => {
      const card = document.createElement('div');
      card.className = 'saved-game-card';

      if (game.status === 'abandoned') {
        card.innerHTML = `
          <div class="saved-game-date">${UICommon.formatDate(game.finishedAt || game.createdAt)}</div>
          <div class="saved-game-row"><span class="saved-game-team">${UICommon.escapeHtml(game.team1.name)} vs ${UICommon.escapeHtml(game.team2.name)}</span></div>
          <div class="saved-game-abandoned">Partida abandonada</div>`;
      } else {
        const s1 = Models.scoreFor(game, game.team1.id);
        const s2 = Models.scoreFor(game, game.team2.id);
        const winnerIsTeam1 = game.winnerTeamId === game.team1.id;
        card.innerHTML = `
          <div class="saved-game-date">${UICommon.formatDate(game.finishedAt || game.createdAt)}</div>
          <div class="saved-game-row ${winnerIsTeam1 ? 'winner' : ''}"><span class="saved-game-team">${winnerIsTeam1 ? '🏆 ' : ''}${UICommon.escapeHtml(game.team1.name)}</span><span class="saved-game-score">${s1}</span></div>
          <div class="saved-game-row ${!winnerIsTeam1 ? 'winner' : ''}"><span class="saved-game-team">${!winnerIsTeam1 ? '🏆 ' : ''}${UICommon.escapeHtml(game.team2.name)}</span><span class="saved-game-score">${s2}</span></div>
          ${game.beerEnabled && game.beerResult && game.beerResult.totalQuantity > 0 ? `<div class="saved-game-beer">🍺 ${game.beerResult.totalQuantity} cerveza(s) generada(s)</div>` : ''}`;
      }

      card.addEventListener('click', () => {
        if (selectMode) toggleSelection(game.id, card);
        else { renderDetail(game); UICommon.showScreen('screen-saved-detail'); }
      });
      container.appendChild(card);
    });
  }

  function toggleSelection(id, card) {
    if (selectedIds.has(id)) { selectedIds.delete(id); card.style.outline = 'none'; }
    else { selectedIds.add(id); card.style.outline = '2px solid var(--accent)'; }
    updateBulkVisibility();
  }
  function updateBulkVisibility() {
    $('#saved-games-bulk-actions').style.display = selectMode && selectedIds.size > 0 ? 'block' : 'none';
  }

  function renderDetail(game) {
    currentDetailGame = game;
    const s1 = Models.scoreFor(game, game.team1.id);
    const s2 = Models.scoreFor(game, game.team2.id);
    $('#sd-name1').textContent = game.team1.name;
    $('#sd-score1').textContent = s1;
    $('#sd-name2').textContent = game.team2.name;
    $('#sd-score2').textContent = s2;

    const beerBox = $('#sd-beer-summary');
    if (game.beerEnabled && game.beerResult && game.beerResult.totalQuantity > 0) {
      const winner = game.winnerTeamId === game.team1.id ? game.team1 : game.team2;
      const loser = Models.otherTeam(game, game.winnerTeamId);
      beerBox.style.display = 'block';
      beerBox.innerHTML = `🍺 <b>${UICommon.escapeHtml(loser.name)}</b> debía(n) <b>${game.beerResult.totalQuantity} 🍺</b> a <b>${UICommon.escapeHtml(winner.name)}</b>`;
    } else {
      beerBox.style.display = 'none';
    }

    UICommon.renderRoundsGrid($('#saved-detail-list'), game, null);
  }

  function bind() {
    $('#btn-select-mode').addEventListener('click', () => {
      selectMode = !selectMode;
      $('#btn-select-mode').style.background = selectMode ? 'var(--accent)' : 'var(--surface)';
      render();
    });
    $('#btn-delete-selected').addEventListener('click', () => {
      UICommon.showConfirm('Eliminar partidas', `Se eliminarán ${selectedIds.size} partida(s) del historial.`, () => {
        StateGame.deleteHistoryGames(Array.from(selectedIds));
        render();
        UICommon.toast('Partidas eliminadas');
      });
    });
    $('#btn-clear-history').addEventListener('click', () => {
      UICommon.showConfirm('Eliminar historial', 'Se eliminarán TODAS las partidas guardadas. Esta acción no se puede deshacer.', () => {
        StateGame.clearAllHistory();
        render();
        UICommon.toast('Historial eliminado');
      });
    });
    $('#btn-share-saved').addEventListener('click', async () => {
      if (!currentDetailGame) return;
      const result = await Share.shareGame(currentDetailGame, UIBoard.playerName);
      if (result.method === 'clipboard') UICommon.toast('Resultado copiado al portapapeles');
    });
  }

  return { render, bind };
})();
