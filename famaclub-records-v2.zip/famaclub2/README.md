# FamaClub Records

"La mesa. El marcador. La historia." — marcador digital de dominó para
4 jugadores / 2 equipos, con sistema de cervezas, deudas, estadísticas
y récords. Reemplaza la hoja de papel de la mesa.

## 1. Tecnología

Se mantiene **PWA (HTML/CSS/JS + Service Worker)**, la misma decisión
de la v1 y por las mismas razones: arranque instantáneo, cero overhead
frente a un motor Flutter/RN, 100% offline, instalable sin tienda.
El salto de esta versión no es de tecnología sino de **modelo de
datos**: jugadores, equipos-dentro-de-partida, y dos ledgers nuevos
(cervezas y deudas) — ver `js/models.js`.

## 2. Decisión de diseño: puntos y cervezas son independientes

Tal como pide la sección 42 del encargo, el marcador de puntos y el
sistema de cervezas **nunca se mezclan matemáticamente**. El único
punto de contacto es `StateBeer.generateDebtsForGame(game)`, invocado
una sola vez cuando `StateGame` detecta un ganador. A partir de ahí,
cervezas, deudas y pagos viven en su propio ledger, completamente
independiente del historial de puntos.

**Cómo se resuelve "por equipo" vs. "por jugador":**
- `equipo`: una sola `BeerDebt` de equipo a equipo (`debtorType: 'team'`).
- `jugador`: una `BeerDebt` por cada jugador del equipo perdedor,
  siempre hacia el equipo ganador como acreedor.
- `personalizado`: se le pregunta al usuario, en el momento de la
  victoria, cuánto debe cada jugador perdedor (con el valor de la
  regla como sugerencia editable).

Esto evita inventar fracciones de cerveza (medio jugador no puede
deber media cerveza) y sigue siendo fiel a cómo se anota en la mesa
real.

## 3. Estructura del proyecto

```
famaclub2/
├── index.html                 ← Landing page (con el logo real)
├── assets/logo*.png            ← Logo proporcionado por el usuario
├── README.md
├── tests/run-tests.js           ← 47 pruebas de lógica de negocio (Node)
└── app/
    ├── index.html                ← Shell de la app (6 pantallas + modales)
    ├── manifest.json               ← Instalación PWA
    ├── service-worker.js            ← Caché offline
    ├── icons/                        ← Íconos generados desde el logo real
    ├── css/styles.css                 ← Un solo archivo, por variables de tema
    └── js/
        ├── models.js                   ← Player, Team, Game, ScoreEntry,
        │                                  BeerEntry, BeerDebt, BeerPayment, Settings
        ├── storage.js                    ← Única puerta a localStorage
        ├── settings.js                    ← AppSettings
        ├── players.js                      ← "Mis jugadores"
        ├── state-game.js                    ← Ciclo de vida de partida + undo/redo
        ├── state-beer.js                     ← Consumo, deudas, pagos
        ├── stats.js                           ← Estadísticas y récords (derivados)
        ├── feedback.js, theme.js, phrases.js, share.js
        └── ui-*.js                             ← Una pantalla por archivo
```

Ningún archivo de lógica de negocio (`models`, `storage`, `state-*`,
`stats`) importa ni toca el DOM — por eso se pueden probar con Node
puro (ver sección 5).

## 4. Qué se implementó (checklist de la sección 51 del encargo)

Todo lo marcado abajo es funcional, no simulado:

- [x] 4 jugadores, 2 equipos, nombres editables, jugadores guardados y reutilizables.
- [x] Puntos configurables (50/100/150/personalizado), registro en 1-2 toques (+5/+10/+15/otros).
- [x] Cuadrícula de rondas editable con colores de ganador por ronda (mejorada respecto a las apps de referencia: es interactiva, no solo de lectura).
- [x] Editar y eliminar cualquier anotación, con recálculo automático — el marcador SIEMPRE se deriva del historial.
- [x] Deshacer / rehacer.
- [x] Detección automática de ganador, incluso protegido contra empates exactos en la meta.
- [x] Guardado automático + "Continuar partida" (incluso si la app se cierra justo en la pantalla de victoria).
- [x] Sistema de cervezas completo: reglas configurables, distribución por equipo/jugador/personalizada.
- [x] Contador personal de cervezas, historial con fecha y hora exacta.
- [x] Deudas con liquidación total o parcial, historial de pagos.
- [x] Estadísticas por jugador y por pareja, récords de la mesa.
- [x] Compartir resultado (tarjeta de imagen vía Canvas + Web Share API, con respaldo de copiar texto).
- [x] Modo mesa (pantalla mínima).
- [x] Modo claro/oscuro/automático + fondo personalizable (color, degradado o imagen, con opacidad).
- [x] Frases divertidas (desactivables).
- [x] 100% offline, sin cuenta, sin permisos innecesarios.
- [x] 47 pruebas automatizadas de la lógica de negocio, todas en verde.

## 5. Pruebas

```
node tests/run-tests.js
```

Corre 47 pruebas contra `state-game.js`, `state-beer.js` y `stats.js`
en Node puro (con un shim mínimo de `localStorage`, sin DOM), cubriendo
exactamente los casos pedidos en la sección 49: crear partida, cambiar
nombres, agregar/editar/eliminar puntos, deshacer/rehacer, detectar
ganador (incluido el empate exacto), guardar/recuperar partida,
abandonar partida, las tres reglas de cerveza, liquidación total y
parcial, independencia entre consumo y deudas, y estadísticas.

## 6. Auditoría QA — hallazgos y correcciones

Durante la auditoría final se encontraron y corrigieron dos problemas
reales antes de la entrega:

1. **Empate exacto en la meta**: si una edición posterior a la
   victoria dejaba a ambos equipos con el mismo puntaje en la meta,
   el estado podía quedar inconsistente (un "ganador" con marcador
   empatado). `checkWinner()` ya negaba el empate, pero `undo/redo`
   no siempre re-sincronizaban `status`/`winnerTeamId` a partir de
   ese resultado. Se unificó toda mutación de puntaje para pasar por
   `syncWinnerState()`, que SIEMPRE recalcula desde cero.
2. **Partida finalizada sin archivar**: si la app se cerraba justo en
   la pantalla de victoria (antes de tocar "Nueva partida" o
   "Inicio"), esa partida no aparecía como "Continuar partida" (porque
   ya no está `active`) ni en el historial (porque nunca se archivó),
   perdiéndose de la vista. Se agregó `resumeIfFinishedUnarchived()`,
   que al abrir la app detecta este caso y retoma la pantalla de
   victoria directamente, sin regenerar cervezas ni repetir sonidos.

## 7. Simplificaciones conocidas (documentadas, no ocultas)

- **"Agregar jugador" en Configuración** usa el `prompt()` nativo del
  navegador en vez de una hoja de diálogo propia — es la única
  interacción de toda la app que lo hace, por ser una acción poco
  frecuente. Se puede reemplazar por un modal propio si se prefiere
  consistencia visual total.
- **Reparto "por equipo" al liquidar**: cuando una deuda es de equipo
  a equipo (regla "por equipo"), la liquidación no pide especificar
  qué jugador exacto pagó — se registra el pago a nivel de equipo. Si
  se necesita saber "quién de los dos pagó realmente", conviene usar
  la regla "por jugador" o "personalizado", que sí crean deudas
  individuales desde el inicio.
- **Reanudar una partida cerrada durante el reparto personalizado de
  cervezas**: si la app se cierra exactamente durante el diálogo de
  "¿quién debe cuánto?" (antes de confirmar), al reabrir se muestra la
  pantalla de victoria sin ese resultado de cervezas; se puede
  registrar manualmente desde la pestaña Cervezas.

Ninguna de estas tres afecta el flujo normal de una partida.

## 8. Cómo obtener un archivo `.apk` real

Igual que en la v1: el proyecto ya trae `manifest.json` + Service
Worker + íconos (ahora generados desde el logo real). Dos caminos
gratuitos para el empaquetado final, que requiere herramientas de
Android no disponibles en este entorno:

**A) PWABuilder** — sube `app/` a un hosting estático (GitHub Pages /
Netlify / Vercel), pega la URL en `pwabuilder.com`, elige Android y
descarga el `.apk` firmado.

**B) Capacitor** — `npx cap init`, copia `app/` a `www/`, `npx cap add
android`, compila con Android Studio. El código no necesita cambios.

## 9. Preparado para crecer

La arquitectura ya deja espacio, sin romper lo existente, para:
partidas de 3-4 jugadores (extender `Team.playerIds`), rankings y
torneos (ya existe el historial completo con jugadores y equipos),
compartir por QR (los datos ya son JSON serializable). No se
implementaron en esta versión para no sacrificar simplicidad.
